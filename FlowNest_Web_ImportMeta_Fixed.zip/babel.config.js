module.exports = {
  presets: [
    [
      'babel-preset-expo',
      {
        // Expo SDK 54 web/Hermes can encounter ESM packages that contain
        // import.meta. Transform it so the generated Metro bundle can run
        // correctly without changing native application code.
        unstable_transformImportMeta: true,
      },
    ],
  ],
  plugins: ['react-native-reanimated/plugin'], // LAST
};
