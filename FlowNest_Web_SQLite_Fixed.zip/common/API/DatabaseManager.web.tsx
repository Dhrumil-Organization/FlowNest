import AsyncStorage from '@react-native-async-storage/async-storage';
import type { CachedPrptype } from './Functions';

/**
 * Web implementation of DatabaseManager.
 *
 * IMPORTANT:
 * - Native DatabaseManager.tsx is intentionally untouched.
 * - Web must not import expo-sqlite because its WASM worker requires
 *   cross-origin isolation / SharedArrayBuffer and can fail in normal Expo web.
 * - AsyncStorage is used as the browser cache for the same exported API.
 */

const PREFIX = '@flownest_db:';
const keyFor = (prptype: string) => `${PREFIX}${prptype}`;
const INDEX_KEY = `${PREFIX}__index__`;

export const initDatabase = async (): Promise<boolean> => {
  // No SQLite initialization on web.
  // AsyncStorage is initialized lazily by the platform implementation.
  return true;
};

export const saveLargeData = async (
  prptype: string,
  data: CachedPrptype,
): Promise<boolean> => {
  try {
    await AsyncStorage.setItem(keyFor(prptype), JSON.stringify(data));

    const raw = await AsyncStorage.getItem(INDEX_KEY);
    const index: string[] = raw ? JSON.parse(raw) : [];

    if (!index.includes(prptype)) {
      index.push(prptype);
      await AsyncStorage.setItem(INDEX_KEY, JSON.stringify(index));
    }

    return true;
  } catch (error) {
    console.warn('❌ Web cache save error:', error);
    return false;
  }
};

export const readPrptypeCache = async (
  prptype: string,
): Promise<CachedPrptype | null> => {
  try {
    const raw = await AsyncStorage.getItem(keyFor(prptype));
    return raw ? (JSON.parse(raw) as CachedPrptype) : null;
  } catch (error) {
    console.warn('❌ Web cache read error:', error);
    return null;
  }
};

export const clearOldChunks = async (prptype: string): Promise<void> => {
  try {
    await AsyncStorage.removeItem(keyFor(prptype));

    const raw = await AsyncStorage.getItem(INDEX_KEY);
    const index: string[] = raw ? JSON.parse(raw) : [];
    const next = index.filter((item) => item !== prptype);
    await AsyncStorage.setItem(INDEX_KEY, JSON.stringify(next));
  } catch (error) {
    console.warn('❌ Web cache clear error:', error);
  }
};

export const getPrptypeIndex = async () => {
  try {
    const raw = await AsyncStorage.getItem(INDEX_KEY);
    const prptypes: string[] = raw ? JSON.parse(raw) : [];
    return { prptypes, count: prptypes.length };
  } catch (error) {
    console.warn('❌ Web cache index error:', error);
    return { prptypes: [], count: 0 };
  }
};

export const getAccountByCode = async (
  prptype: string,
  acccode: string,
) => {
  const cache = await readPrptypeCache(prptype);
  if (!cache?.account || !Array.isArray(cache.account)) return null;

  return (
    cache.account.find(
      (item: any) => String(item?.acccode ?? '') === String(acccode),
    ) ?? null
  );
};

export const getBankByName = async (
  prptype: string,
  bankName: string,
) => {
  const cache = await readPrptypeCache(prptype);
  if (!cache?.banks || !Array.isArray(cache.banks)) return null;

  return (
    cache.banks.find(
      (item: any) => String(item?.BankName ?? '') === String(bankName),
    ) ?? null
  );
};
