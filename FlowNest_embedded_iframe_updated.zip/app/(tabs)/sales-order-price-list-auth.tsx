import AsyncStorage from '@/common/utils/compatibleStorage';
import React, { useEffect, useState } from 'react';

// import { AuthProvider, useAuth } from '@/hooks/AuthContext';
// import GreyPurchaseOrder from '@/components/GreyPurchaseOrder';
import SalesOrderPriceListAuth from '@/components/SalesOrderPriceListAuth';

export default function CRLimit_Request_Container() {
    // const { token, username } = useAuth();
    const [token, setToken] = useState('');
    const [username, setUsername] = useState('');
    const [getUserPrptype, setUserPrp] = useState('');
    const [getUserId, setUserId] = useState();

    useEffect(() => {
        const load = async () => {
            const t = await AsyncStorage.getItem('access_token');
            const u = await AsyncStorage.getItem('user_details');
            const p = await AsyncStorage.getItem('user_prptype');
            const i = await AsyncStorage.getItem('user_id');

            setToken(t || '');
            setUsername(u || 'User');
            setUserPrp(p || '')
            setUserId(p)
        };
        load();
    }, []);

    return (
        <>
            {/* <AuthProvider> */}
            <SalesOrderPriceListAuth token={token || ''} username={username} userid={getUserId} />
            {/* <Footer /> */}
            {/* </AuthProvider> */}
        </>
    );
}