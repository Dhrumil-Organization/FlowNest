import { APP_NAVIGATION } from '@/src/core/navigation';
import { usePermission } from '@/src/core/permissions';
import { useAppSessionStore } from '@/src/stores/AppSessionStore';
import { T } from '@/src/theme';
import Icon from '@expo/vector-icons/MaterialIcons';
import { Tabs } from 'expo-router';
import React from 'react';

export default function TabsLayout() {
  const { canAccess, canDo } = usePermission();
  const hydrated = useAppSessionStore((state) => state.hydrated);
  const appSession = useAppSessionStore((state) => state.appSession);
  const ready = hydrated && Boolean(appSession?.permissions);

  const allowed = (key: keyof typeof APP_NAVIGATION) => {
    if (!ready) return false;
    const item = APP_NAVIGATION[key];
    return item.action ? canDo(item.resource, item.action) : canAccess(item.resource);
  };

  const option = (key: keyof typeof APP_NAVIGATION, visible: boolean) => {
    const item = APP_NAVIGATION[key];
    return {
      title: item.title,
      tabBarIcon: ({ color }: { color: string }) => <Icon name={item.icon as any} size={24} color={color} />,
      href: visible ? undefined : null,
    } as const;
  };

  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: T.copper,
      tabBarInactiveTintColor: T.muted,
      tabBarStyle: { height: 64, backgroundColor: T.surface, borderTopColor: T.border },
      tabBarLabelStyle: { fontSize: 10, fontWeight: '800', marginBottom: 7 },
      tabBarIconStyle: { marginTop: 7 },
    }}>
      <Tabs.Screen name="index" options={option('home', true)} />
      <Tabs.Screen name="designs" options={option('designs', allowed('designs'))} />
      <Tabs.Screen name="costing" options={option('costing', allowed('costing'))} />
      <Tabs.Screen name="orders" options={option('orders', allowed('orders'))} />
      <Tabs.Screen name="reports" options={option('reports', allowed('reports'))} />
      <Tabs.Screen name="permissions/index" options={option('permissions', allowed('permissions'))} />
    </Tabs>
  );
}
