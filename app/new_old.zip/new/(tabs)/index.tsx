// import { DashboardScreen } from '@/src/screens/dashboard/DashboardScreen';

// export default DashboardScreen;


import { DashboardScreen as DashboardScreen1 } from '@/src/screens/dashboard/DashboardScreen';
import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useState } from 'react';

export default function DashboardScreen() {
    // const { token, username } = useAuth();
    const [token, setToken] = useState('');
    const [username, setUsername] = useState('');
    const [getUserPrptype, setUserPrp] = useState('');

    useEffect(() => {
        const load = async () => {
            const t = await AsyncStorage.getItem('access_token');
            const u = await AsyncStorage.getItem('user_details');
            const p = await AsyncStorage.getItem('user_prptype');

            setToken(t || '');
            setUsername(u || 'User');
            setUserPrp(p || '')
        };
        load();
    }, []);

    return (
        <>
            {/* <AuthProvider> */}
            <DashboardScreen1 token={token || ''} getUserPrptype={getUserPrptype} />
            {/* <Footer/> */}
            {/* </AuthProvider> */}
        </>
    );
}