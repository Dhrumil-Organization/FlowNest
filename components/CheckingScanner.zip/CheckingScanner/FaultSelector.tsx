// FILE: components/CheckingScanner/FaultSelector.tsx
//
// Shared "Select Faults" UI used by BOTH FaultsModal (Manual Entry + QR
// Scanner tabs) and ScannerFaultsModal (Scanner List rows).
//
// IMPORTANT — the BROWSE response is the single source of truth:
//   - On open, the parent fetches the catalog via get_checking_fault_help
//     ("browse"). That response IS `catalog` — every fault the checker can
//     pick from, each one already carrying whatever `Remark` value it has
//     right now (empty string if none).
//   - This component never keeps its own copy of "what's added" — it just
//     derives it from `catalog` on every render:
//       · Top grid   -> ALL catalog items, plain name only, tappable.
//       · Added list -> only the catalog items whose Remark is non-empty,
//                        shown as a chip (name + remark) + an X, in a
//                        distinct colour.
//   - Tapping a top-grid chip (with a Fault Value typed in) calls
//     onAddFault(item, value). Tapping an added chip's X calls
//     onRemoveFault(item). Both are fully owned by the parent: it builds
//     the whole-catalog `d1` payload (isEntry: 1 only for items that end
//     up with a non-empty Remark, 0 for every other item), POSTs
//     add_checking_fault, and on success re-runs the SAME browse call to
//     refresh `catalog` — so whatever the server says is exactly what
//     renders next. This component just waits for the new `catalog` prop.
//
// Both the top grid and the added-list are fixed-height, independently
// vertically-scrolling boxes, so the modal never grows unbounded no
// matter how many faults exist.
import Icon from '@expo/vector-icons/MaterialIcons';
import React, { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  useWindowDimensions,
  View,
} from 'react-native';

export interface FaultCatalogItem {
  Faults: string;
  RDesc: string;
  Remark?: string;
  RsnCode: string;
  SrNo: string;
  SubSr: string;
  UId: string;
}

interface FaultSelectorProps {
  visible: boolean;
  title?: string;
  catalog: FaultCatalogItem[];
  catalogLoading?: boolean;
  busy?: boolean;
  busyItemKey?: string | null;
  beamNo?: string;
  takaNo?: string;
  meter?: string;
  onClose: () => void;
  onAddFault: (fault: FaultCatalogItem, remarkValue: string) => void;
  onRemoveFault: (fault: FaultCatalogItem) => void;
}

const itemKey = (item: FaultCatalogItem) => `${item.UId ?? ''}_${item.SubSr ?? ''}`;
const sanitizeRemarkInput = (text: string) => text.replace(/[^0-9,\- ]/g, '');

const FaultSelector: React.FC<FaultSelectorProps> = ({
  visible,
  title = 'Select Faults',
  catalog,
  catalogLoading = false,
  busy = false,
  busyItemKey = null,
  beamNo = '',
  takaNo = '',
  meter = '',
  onClose,
  onAddFault,
  onRemoveFault,
}) => {
  const [faultValue, setFaultValue] = useState('');
  const [searchText, setSearchText] = useState('');
  const [validationMsg, setValidationMsg] = useState('');

  const { width } = useWindowDimensions();
  const isMobile = Platform.OS !== 'web'; // native app (phone/tablet build)
  const isCompact = width < 360;
  const isTablet = width >= 768;
  const isWebWide = Platform.OS === 'web' && width >= 900;

  React.useEffect(() => {
    if (!visible) {
      setSearchText('');
      setFaultValue('');
      setValidationMsg('');
    }
  }, [visible]);

  // Clear the Fault Value box the moment a fault finishes saving (catalog
  // prop changing after a successful add is our signal that it went
  // through — see FaultsModal/ScannerFaultsModal).
  const prevBusyRef = React.useRef(busy);
  React.useEffect(() => {
    if (prevBusyRef.current && !busy) {
      setFaultValue('');
    }
    prevBusyRef.current = busy;
  }, [busy]);

  const handleFaultValueChange = (text: string) => {
    setValidationMsg('');
    setFaultValue(sanitizeRemarkInput(text));
  };

  const handleChipPress = (item: FaultCatalogItem) => {
    if (busy) return;
    const value = faultValue.trim();
    if (!value) {
      setValidationMsg('Please enter a Fault Value before selecting a fault.');
      return;
    }
    onAddFault(item, value);
  };

  const q = searchText.trim().toLowerCase();
  const matchesQuery = (item: FaultCatalogItem) =>
    !q ||
    (item.RDesc ?? '').toLowerCase().includes(q) ||
    (item.RsnCode ?? '').toLowerCase().includes(q) ||
    String(item.SubSr ?? '').toLowerCase().includes(q) ||
    (item.Faults ?? '').toLowerCase().includes(q) ||
    (item.Remark ?? '').toLowerCase().includes(q);

  const filteredCatalog = useMemo(() => catalog.filter(matchesQuery), [catalog, q]);

  // Only faults that currently carry a Remark are "added" — this list is
  // derived straight from `catalog`, never stored separately.
  const addedFaults = useMemo(
    () => catalog.filter((item) => String(item.Remark ?? '').trim() !== ''),
    [catalog]
  );
  const filteredAdded = useMemo(() => addedFaults.filter(matchesQuery), [addedFaults, q]);

  // Web renders comfortably bigger; the native app (phone AND tablet
  // build) stays compact so more fits on screen without crowding.
  const fontScale = isWebWide ? 1.12 : isCompact ? 0.88 : isMobile ? 0.95 : 1;
  const t = (base: number) => Math.round(base * fontScale);
  const columnsWide = isWebWide || isTablet;

  return (
    <Modal visible={visible} animationType="fade" transparent>
      <View style={s.overlay}>
        <View style={[s.card, isWebWide && s.cardWide]}>
          <View style={s.header}>
            <Text style={[s.title, { fontSize: t(19) }]}>{title}</Text>
            <TouchableOpacity onPress={onClose} style={s.closeBtn} activeOpacity={0.7}>
              <Icon name="close" size={23} color="#334155" />
            </TouchableOpacity>
          </View>

          {(!!beamNo || !!takaNo || !!meter) && (
            <View style={s.infoCard}>
              <View style={s.infoItem}>
                <Text style={[s.infoLabel, { fontSize: t(10) }]}>Beam No</Text>
                <Text style={[s.infoValue, { fontSize: t(13) }]} numberOfLines={1}>{beamNo || '-'}</Text>
              </View>
              <View style={s.infoDivider} />
              <View style={[s.infoItem, s.takaItem]}>
                <Text style={[s.infoLabel, { fontSize: t(10) }]}>Taka No</Text>
                <Text style={[s.infoValue, { fontSize: t(13) }]} numberOfLines={1}>{takaNo || '-'}</Text>
              </View>
              <View style={s.infoDivider} />
              <View style={s.meterItem}>
                <Text style={[s.infoLabel, { fontSize: t(10) }]}>Meter</Text>
                <Text style={[s.infoValue, { fontSize: t(13) }]} numberOfLines={1}>{meter || '-'}</Text>
              </View>
            </View>
          )}

          <Text style={[s.fieldLabel, { fontSize: t(14) }]}>
            Fault Value <Text style={s.required}>*</Text>
          </Text>
          <TextInput
            style={[s.faultValueInput, { fontSize: t(13) }]}
            placeholder="Enter value (e.g. 123, 345-678)"
            placeholderTextColor="#94A3B8"
            value={faultValue}
            onChangeText={handleFaultValueChange}
            editable={!busy}
          />
          {!!validationMsg && <Text style={[s.validationMsg, { fontSize: t(11) }]}>{validationMsg}</Text>}

          <View style={s.searchContainer}>
            <Icon name="search" size={19} color="#64748B" style={s.searchIcon} />
            <TextInput
              style={[s.searchInput, { fontSize: t(13) }]}
              placeholder="Search by description or code"
              placeholderTextColor="#94A3B8"
              value={searchText}
              onChangeText={setSearchText}
            />
            {searchText.length > 0 && (
              <TouchableOpacity onPress={() => setSearchText('')}>
                <Icon name="close" size={16} color="#64748B" />
              </TouchableOpacity>
            )}
          </View>

          {/* ── Fault catalog — plain, clickable, fixed height, own scroll ── */}
          <Text style={[s.selectLabel, { fontSize: t(13.5), marginTop: 12 }]}>
            Select Faults <Text style={s.required}>*</Text>
          </Text>
          <View style={[s.catalogBox, isTablet && s.catalogBoxTablet]}>
            {catalogLoading ? (
              <ActivityIndicator size="large" color="#2563EB" style={{ marginVertical: 24 }} />
            ) : (
              <ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled">
                <View style={s.faultGrid}>
                  {filteredCatalog.map((item, index) => {
                    const key = itemKey(item);
                    const label = item.RDesc || item.Faults || item.RsnCode || `Fault ${index + 1}`;
                    const hasValue = String(item.Remark ?? '').trim() !== '';
                    const saving = busy && busyItemKey === key;
                    return (
                      <TouchableOpacity
                        key={key || index}
                        activeOpacity={0.75}
                        disabled={busy}
                        onPress={() => handleChipPress(item)}
                        style={[
                          s.faultChip,
                          columnsWide && s.faultChipWide,
                          // hasValue && s.faultChipActive,
                        ]}
                      >
                        {saving ? (
                          <ActivityIndicator size="small" color="#2563EB" />
                        ) : (
                          // <Text
                          //   style={[s.faultChipText, hasValue && s.faultChipTextActive, { fontSize: t(12) }]}
                          //   numberOfLines={2}
                          // >
                          //   {label}
                          // </Text>
                          <Text
                            style={{ fontSize: t(12) }}
                            numberOfLines={2}
                          >
                            {label}
                          </Text>
                        )}
                      </TouchableOpacity>
                    );
                  })}
                  {filteredCatalog.length === 0 && (
                    <Text style={[s.noResultText, { fontSize: t(12) }]}>No matching faults found</Text>
                  )}
                </View>
              </ScrollView>
            )}
          </View>

          {/* ── Added Faults — fixed height, own vertical scroll ── */}
          <View style={s.sectionHeaderRow}>
            <Text style={[s.selectLabel, { fontSize: t(13.5) }]}>Added Faults</Text>
            <Text style={[s.countBadge, { fontSize: t(11) }]}>{addedFaults.length}</Text>
          </View>
          <View style={[s.addedBox, isTablet && s.addedBoxTablet]}>
            <ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled">
              <View style={s.entriesWrap}>
                {filteredAdded.length === 0 && (
                  <Text style={[s.noResultText, { fontSize: t(12) }]}>
                    {addedFaults.length === 0 ? 'No fault added yet' : 'No matching added faults'}
                  </Text>
                )}
                {filteredAdded.map((item) => {
                  const key = itemKey(item);
                  const label = item.RDesc || item.Faults || item.RsnCode || 'Fault';
                  const removing = busy && busyItemKey === key;
                  return (
                    <View key={key} style={s.entryChip}>
                      <Text style={[s.entryChipText, { fontSize: t(12) }]} numberOfLines={2}>
                        {label}
                        <Text style={s.entryChipRemark}>  · {item.Remark}</Text>
                      </Text>
                      <TouchableOpacity
                        onPress={() => onRemoveFault(item)}
                        disabled={busy}
                        style={s.entryChipClose}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        {removing ? (
                          <ActivityIndicator size="small" color="#B91C1C" />
                        ) : (
                          <Icon name="close" size={14} color="#B91C1C" />
                        )}
                      </TouchableOpacity>
                    </View>
                  );
                })}
              </View>
            </ScrollView>
          </View>


        </View>
      </View>
    </Modal>
  );
};

// Palette kept muted/professional (slate + blue) instead of bright
// orange/green, consistent across web, tablet and phone.
const s = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.40)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 22,
  },
  card: {
    width: '100%',
    maxWidth: 640,
    maxHeight: '92%',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 14,
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.16,
    shadowRadius: 18,
    elevation: 12,
  },
  cardWide: { maxWidth: 760, paddingHorizontal: 22 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  title: { color: '#0F172A', fontWeight: '700' },
  closeBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center', borderRadius: 16 },
  infoCard: {
    minHeight: 52,
    backgroundColor: '#F1F5F9',
    borderRadius: 9,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    marginBottom: 13,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  infoItem: { width: '25%', minWidth: 68 },
  takaItem: { flex: 1, width: undefined },
  meterItem: { width: '18%', minWidth: 50 },
  infoDivider: { width: 1, height: 30, backgroundColor: '#CBD5E1', marginHorizontal: 8 },
  infoLabel: { color: '#64748B', marginBottom: 2, fontWeight: '600' },
  infoValue: { color: '#0F172A', fontWeight: '700' },
  fieldLabel: { color: '#1E293B', fontWeight: '600', marginBottom: 6 },
  required: { color: '#DC2626' },
  faultValueInput: {
    height: 42,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    borderRadius: 8,
    paddingHorizontal: 12,
    color: '#0F172A',
    backgroundColor: '#FFFFFF',
  },
  validationMsg: { color: '#DC2626', marginTop: 4 },
  searchContainer: {
    height: 40,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#CBD5E1',
    borderRadius: 8,
    paddingHorizontal: 10,
    backgroundColor: '#FFFFFF',
    marginTop: 10,
    marginBottom: 10,
  },
  searchIcon: { marginRight: 6 },
  searchInput: { flex: 1, paddingVertical: 0, color: '#0F172A' },
  sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  selectLabel: { color: '#1E293B', fontWeight: '600' },
  countBadge: {
    color: '#334155',
    fontWeight: '700',
    backgroundColor: '#E2E8F0',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    overflow: 'hidden',
  },
  // Fixed-height + internal scroll so the list never balloons the modal.
  addedBox: {
    height: 96,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 10,
    backgroundColor: '#F8FAFC',
    padding: 8,
  },
  addedBoxTablet: { height: 116 },
  catalogBox: {
    height: 190,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    padding: 8,
  },
  catalogBoxTablet: { height: 230 },
  entriesWrap: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'flex-start' },
  entryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    maxWidth: '100%',
    paddingLeft: 11,
    paddingRight: 7,
    paddingVertical: 7,
    marginRight: 7,
    marginBottom: 7,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#BFDBFE',
    backgroundColor: '#EFF6FF',
  },
  entryChipText: { color: '#1D4ED8', fontWeight: '600', maxWidth: 210 },
  entryChipRemark: { color: '#0F172A', fontWeight: '800' },
  entryChipClose: { marginLeft: 7, padding: 2 },
  faultGrid: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'flex-start' },
  faultChip: {
    minHeight: 40,
    maxWidth: '48%',
    paddingHorizontal: 11,
    paddingVertical: 8,
    marginRight: '2%',
    marginBottom: 7,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
  },
  faultChipWide: { maxWidth: '32%' },
  faultChipActive: { borderColor: '#93C5FD', backgroundColor: '#EFF6FF' },
  faultChipText: { color: '#334155', fontWeight: '500', textAlign: 'center' },
  faultChipTextActive: { color: '#1D4ED8', fontWeight: '700' },
  noResultText: { width: '100%', textAlign: 'center', color: '#94A3B8', marginVertical: 12 },
});

export default FaultSelector;
