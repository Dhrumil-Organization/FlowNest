// FILE: components/CheckingScanner/ScannerFaultsModal.tsx
// "Faults" modal opened from a Scanner List row (already-saved checking
// record — real SrNo/UId). Same browse-driven flow as FaultsModal:
//   1. Open -> get_checking_fault_help ("browse") populates `catalog`,
//      every item carrying its current Remark (empty if none).
//   2. Tap a catalog chip (Fault Value filled in) -> POST add_checking_fault
//      with the FULL catalog as `d1`, each item's `IsEntry` set to 1 if its
//      Remark ends up non-empty, 0 otherwise.
//   3. On success, re-run the browse call so the UI always reflects exactly
//      what the server has.
//   4. X on an added chip clears that item's Remark and repeats step 2/3.
import { API } from '@/common/API/dynamicAPI';
import { getCurrentFinancialYear } from '@/common/commonfunction';
import { showError } from '@/common/utils/snackbar';
import axios from 'axios';
import React, { useCallback, useEffect, useState } from 'react';
import FaultSelector, { FaultCatalogItem } from './FaultSelector';

interface ScannerFaultsModalProps {
  visible: boolean;
  token: string;
  rowData: any;
  loading?: boolean;
  onClose: () => void;
  // Fired (fire-and-forget) after every successful refresh so the parent
  // can silently update the underlying Scanner List row, without closing
  // this modal.
  onSaved?: () => void;
}

const same = (a: FaultCatalogItem, b: FaultCatalogItem) => a.UId === b.UId && a.SubSr === b.SubSr;

const ScannerFaultsModal: React.FC<ScannerFaultsModalProps> = ({
  visible,
  token,
  rowData,
  loading = false,
  onClose,
  onSaved,
}) => {
  const [catalog, setCatalog] = useState<FaultCatalogItem[]>([]);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [busyItemKey, setBusyItemKey] = useState<string | null>(null);

  const headers = {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
  };

  const buildPayloadBase = () => ({
    ShfCode: rowData?.ShfCode || '',
    ChkDate: rowData?.ChkDate || '',
    MacGrp: rowData?.MacGrp || '',
    PrpCode: rowData?.PrpCode || '',
    BeamNo: rowData?.BeamNo || '',
    SrNo: rowData?.SrNo || '',
    UId: rowData?.UId || '',
    yearno: getCurrentFinancialYear(),
    txntype: 'beam_checking',
    IsEntry: "1",
  });

  // The "browse" call — always the source of truth for what's rendered.
  const loadCatalog = useCallback(async () => {
    if (!rowData) return;
    setCatalogLoading(true);
    try {
      const response = await axios.get(`${API}/api/get_checking_fault_help`, {
        headers,
        params: buildPayloadBase(),
      });
      const apiData: FaultCatalogItem[] =
        response?.data?.data || response?.data?.response?.data || [];
      setCatalog(apiData);
    } catch (error) {
      console.log('ScannerFaultsModal loadCatalog error:', error);
      setCatalog([]);
    } finally {
      setCatalogLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rowData]);

  useEffect(() => {
    if (visible) loadCatalog();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible, rowData]);

  const persistAndRefresh = async (targetItem: FaultCatalogItem, remarkValue: string) => {
    const d1 = catalog.map((c) => {
      const remark = same(c, targetItem) ? remarkValue : String(c.Remark ?? '');
      return {
        Faults: c.Faults,
        RDesc: c.RDesc,
        RsnCode: c.RsnCode,
        SrNo: c.SrNo,
        SubSr: c.SubSr,
        UId: c.UId,
        Remark: remark,
        // IsEntry: remark.trim() !== '' ? "1" : "0",
      };
    });

    const payload = { ...buildPayloadBase(), IsEntry: "1", d1 };
    return axios.post(`${API}/api/add_checking_fault`, payload, { headers });
  };

  const handleAddFault = async (fault: FaultCatalogItem, remarkValue: string) => {
    const key = `${fault.UId}_${fault.SubSr}`;
    setBusy(true);
    setBusyItemKey(key);
    try {
      const response = await persistAndRefresh(fault, remarkValue);
      if (response.data?.success) {
        await loadCatalog();
        onSaved?.();
      } else {
        showError(response.data?.message || 'Fault save failed');
      }
    } catch (error) {
      console.log('ScannerFaultsModal handleAddFault error:', error);
      showError('Unable to save fault.');
    } finally {
      setBusy(false);
      setBusyItemKey(null);
    }
  };

  const handleRemoveFault = async (fault: FaultCatalogItem) => {
    const key = `${fault.UId}_${fault.SubSr}`;
    setBusy(true);
    setBusyItemKey(key);
    try {
      const response = await persistAndRefresh(fault, '');
      if (response.data?.success) {
        await loadCatalog();
        onSaved?.();
      } else {
        showError(response.data?.message || 'Unable to remove fault');
      }
    } catch (error) {
      console.log('ScannerFaultsModal handleRemoveFault error:', error);
      showError('Unable to remove fault.');
    } finally {
      setBusy(false);
      setBusyItemKey(null);
    }
  };

  return (
    <FaultSelector
      visible={visible}
      title="Scanner Faults"
      catalog={catalog}
      catalogLoading={catalogLoading}
      busy={busy || loading}
      busyItemKey={busyItemKey}
      beamNo={rowData?.BeamNo || ''}
      takaNo={rowData?.TakaNo || ''}
      meter={rowData?.Qty || rowData?.Meter || ''}
      onClose={onClose}
      onAddFault={handleAddFault}
      onRemoveFault={handleRemoveFault}
    />
  );
};

export default ScannerFaultsModal;
