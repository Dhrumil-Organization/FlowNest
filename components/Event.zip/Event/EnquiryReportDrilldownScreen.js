// EnquiryReportDrilldownScreen.js
// Per-user enquiry drilldown: list, view detail, edit, delete.
// EXPO version — icons via @expo/vector-icons.

import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Modal,
  ScrollView,
  RefreshControl,
  Alert,
} from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import api from './api';
import { API } from '@/common/API/dynamicAPI';
import { MaterialIcons as Icon } from '@expo/vector-icons';
import { getCurrentFinancialYear } from '../../common/commonfunction';
import { deleteEnquiries } from './syncService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import HeaderBarwithBack from '@/components/Header';
import { useLocalSearchParams, useRouter } from 'expo-router';

export default function EnquiryReportDrilldownScreen({ username }) {
  const router = useRouter();
  const params = useLocalSearchParams();
  const { userId, userName, userRole, eventCode } = params;
  const [loading, setLoading] = useState(true);
  const [enquiries, setEnquiries] = useState([]);
  const [selected, setSelected] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  // Load enquiries
  const loadEnquiries = useCallback(async () => {
    try {
      setLoading(true);
      const res = await api.get(
        `${API}/api/reports/enquiries/user/${userId}?prptype=S&yearno=27`,
        {
          params: { event: eventCode },
        },
      );
      console.log('User enquiries:', userId, res.data.enquiries);
      setEnquiries(res.data.enquiries || []);
    } catch (err) {
      console.log('Failed to load user enquiries:', err.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [userId, eventCode]);

  // Reload enquiries when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      loadEnquiries();
    }, [loadEnquiries]),
  );

  // Set header title
  // useEffect(() => {
  //   router.setOptions({ title: userName });
  // }, [router, userName]);

  // Handle Edit button press
  const handleEdit = item => {
    setSelected(null); // Close modal if open
    // navigation.navigate('Event', { id: item.id });
    router.push({
      pathname: '/event',
      params: {
        id: item.id
      }
    });
  };

  // Handle Delete button press
  const handleDelete = async item => {
    setSelected(null); // Close modal if open
    // navigation.navigate('EnquiryReportDrilldown', { id: item.id });
    try {
      const token = await AsyncStorage.getItem('access_token');
      const user_prptype = await AsyncStorage.getItem('user_prptype');
      const result = await deleteEnquiries(
        item.id,
        token,
        getCurrentFinancialYear(),
        user_prptype,
      );

      console.log(
        'API RESULT =>',
        getCurrentFinancialYear(),
        user_prptype,
        result,
      );

      if (result.success === true) {
        Alert.alert(`${result.message} for ${item.party_name}!`);
        loadEnquiries();
      }
    } catch (err) {
      console.log('LOAD ERROR =>', err);
    }
  };

  // Render each row in the FlatList
  const renderRow = ({ item }) => (
    <TouchableOpacity style={styles.row} onPress={() => setSelected(item)}>
      <View style={styles.rowLeft}>
        <Text style={styles.party}>{item.party_name}</Text>
        <Text style={styles.sub}>
          {item.contact_name || 'No contact name'} ·{' '}
          {formatDate(item.created_at)}
        </Text>
      </View>
      <View style={styles.rowRight}>
        <Text style={styles.qty}>
          <Text style={styles.qtyNum}>
            {Number(item.qty_required || 0).toLocaleString()}
          </Text>{' '}
          m
        </Text>
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.editBtn}
            onPress={() => handleEdit(item)}
          >
            <Icon name="edit" color="#2196F3" size={20} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.deleteBtn}
            onPress={() => handleDelete(item)}
          >
            <Icon name="delete" color="#F44336" size={20} />
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );

  // Format date
  const formatDate = dateStr => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return (
      d.toLocaleDateString() +
      ' ' +
      d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    );
  };

  // Pull-to-refresh handler
  const onRefresh = () => {
    setRefreshing(true);
    loadEnquiries();
  };

  // Render header with refresh button
  const renderHeader = () => (
    <View style={styles.header}>
      <Text style={styles.headerName}>{userName}</Text>
      <View style={styles.headerRow}>
        <Text style={styles.headerSub}>
          {userRole} · {enquiries.length} enquiries
        </Text>
        <TouchableOpacity style={styles.refreshBtn} onPress={onRefresh}>
          <Icon name="refresh" color="#6b7280" size={20} />
        </TouchableOpacity>
      </View>
    </View>
  );

  // Loading indicator
  if (loading && !refreshing) {
    return (
      <View style={styles.centerScreen}>
        <ActivityIndicator color="#c2622f" size="large" />
      </View>
    );
  }

  return (
    <>
      <HeaderBarwithBack
        userName={username}
        header={'Event Report Details'}
        breadcrumb={'Event Report Details'}
        SearchBar={false}
      />
      <View style={styles.screen}>
        <FlatList
          data={enquiries}
          keyExtractor={item => String(item.id)}
          renderItem={renderRow}
          ListHeaderComponent={renderHeader}
          ListEmptyComponent={
            <Text style={styles.empty}>No enquiries from this user yet.</Text>
          }
          contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />

        {/* Detail Modal */}
        <Modal
          visible={!!selected}
          animationType="slide"
          transparent
          onRequestClose={() => setSelected(null)}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalCard}>
              <TouchableOpacity
                style={styles.modalClose}
                onPress={() => setSelected(null)}
              >
                <Icon name="close" color="#6b7280" size={24} />
              </TouchableOpacity>
              {selected && (
                <ScrollView>
                  <Text style={styles.modalTitle}>{selected.party_name}</Text>
                  <Text style={styles.modalSub}>
                    Enquiry #{selected.id} · {formatDate(selected.created_at)}
                  </Text>

                  <DetailRow
                    label="Contact name"
                    value={selected.contact_name}
                  />
                  <DetailRow label="Mobile" value={selected.mobile} />
                  <DetailRow label="Email" value={selected.email} />
                  <DetailRow label="Address" value={selected.address} />
                  <DetailRow label="GST No." value={selected.gst_no} />
                  <DetailRow
                    label="Design requirement"
                    value={selected.design_requirement}
                  />
                  <DetailRow
                    label="Colour requirement"
                    value={selected.colour_requirement}
                  />
                  <DetailRow
                    label="Qty required"
                    value={
                      selected.qty_required
                        ? `${Number(selected.qty_required).toLocaleString()} m`
                        : null
                    }
                  />
                  <DetailRow
                    label="Price"
                    value={selected.price ? `₹${selected.price}/m` : null}
                  />
                </ScrollView>
              )}
            </View>
          </View>
        </Modal>
      </View>
    </>
  );
}

// Detail Row Component
function DetailRow({ label, value }) {
  return (
    <View style={styles.detailRow}>
      <Text style={styles.detailKey}>{label}</Text>
      <Text style={styles.detailVal}>{value || '—'}</Text>
    </View>
  );
}

// Styles
const C = {
  brand: '#B3552C',
  ink: '#1F2937',
  body: '#374151',
  muted: '#6B7280',
  bg: '#FBFAF7',
  surface: '#FFFFFF',
  border: '#ECE9E2',
  editBg: '#E8F0FE',
  deleteBg: '#FDECEA',
};

const shadowSoft = {
  shadowColor: '#000',
  shadowOffset: { width: 0, height: 4 },
  shadowOpacity: 0.06,
  shadowRadius: 10,
  elevation: 2,
};

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  header: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 12 },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerName: { fontSize: 18, fontWeight: '800', color: C.ink },
  headerSub: { fontSize: 12, color: C.muted, marginTop: 2 },
  refreshBtn: { padding: 6, borderRadius: 8, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 12,
    backgroundColor: C.surface,
    padding: 14,
    marginBottom: 10,
    ...shadowSoft,
  },
  rowLeft: { flex: 1 },
  party: { fontSize: 14, fontWeight: '800', color: C.ink },
  sub: { fontSize: 11.5, color: C.muted, marginTop: 2 },
  rowRight: { alignItems: 'flex-end', flexDirection: 'row', gap: 8 },
  qty: { fontSize: 13, color: C.body },
  qtyNum: { fontWeight: '800' },
  buttonContainer: { flexDirection: 'row', gap: 8 },
  editBtn: { padding: 8, backgroundColor: C.editBg, borderRadius: 9 },
  deleteBtn: { padding: 8, backgroundColor: C.deleteBg, borderRadius: 9 },
  empty: { textAlign: 'center', color: C.muted, fontSize: 13, marginTop: 40 },
  centerScreen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.bg,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(17,19,21,0.45)',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: {
    backgroundColor: C.surface,
    borderRadius: 16,
    padding: 20,
    maxHeight: '80%',
    ...shadowSoft,
  },
  modalClose: { position: 'absolute', top: 14, right: 16, zIndex: 1 },
  modalTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: C.ink,
    marginBottom: 2,
    paddingRight: 24,
  },
  modalSub: { fontSize: 11.5, color: C.muted, marginBottom: 14 },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  detailKey: { fontSize: 13, color: C.muted },
  detailVal: {
    fontSize: 13,
    color: C.ink,
    fontWeight: '600',
    textAlign: 'right',
    maxWidth: '60%',
  },
});
