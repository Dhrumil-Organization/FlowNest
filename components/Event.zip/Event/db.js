// db.js
// ────────────────────────────────────────────────────────────────────────────
// Offline SQL cache for enquiries — EXPO version.
//
// IMPORTANT (why this file changed):
//   The previous Expo port mixed two different expo-sqlite APIs:
//     • SQLite.openDatabase()      → legacy WebSQL API (no execAsync/runAsync)
//     • db.execAsync(sql, params)  → new API, BUT execAsync ignores params
//   Result: SELECTs worked by luck, every INSERT/UPDATE silently did nothing.
//
//   This rewrite uses ONLY the modern async API the way Expo documents it:
//     • SQLite.openDatabaseAsync('bharattex.db')   → open
//     • db.execAsync(sql)                          → schema / bulk (NO params)
//     • db.runAsync(sql, [params])                 → INSERT / UPDATE / DELETE
//     • db.getAllAsync(sql, [params])              → SELECT (array of rows)
//     • db.getFirstAsync(sql, [params])            → SELECT one row
//
//   Behaviour is identical to your working react-native-sqlite-storage version.
//
// Install (managed Expo):
//   npx expo install expo-sqlite @react-native-async-storage/async-storage
// ────────────────────────────────────────────────────────────────────────────

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SQLite from 'expo-sqlite';
import { API } from '../../common/API/dynamicAPI';
import { getCurrentFinancialYear } from '../../common/commonfunction';
import api from './api'; // your axios instance

const DB_NAME = 'bharattex.db';

const EVENTS_CACHE_KEY = 'cached_events';
const DESIGNS_CHUNK_PREFIX = 'cached_designs_chunk_';
const DESIGNS_META_KEY = 'cached_designs_meta';
const ITEM_CHUNK_PREFIX = 'cached_item_chunk_';
const ITEM_META_KEY = 'cached_item_meta';
const CHUNK_SIZE = 500;

// ════════════════════════ CACHING LOGIC (AsyncStorage) ═════════════════════
// AsyncStorage works out of the box in Expo, so this logic is unchanged.

export const getCachedEvents = async () => {
  try {
    const data = await AsyncStorage.getItem(EVENTS_CACHE_KEY);
    return data ? JSON.parse(data) : null;
  } catch (e) {
    return null;
  }
};

export const setCachedEvents = async events => {
  try {
    await AsyncStorage.setItem(EVENTS_CACHE_KEY, JSON.stringify(events));
  } catch (e) {
    console.log('Failed to cache events', e);
  }
};

export const clearCachedEvents = async () => {
  try {
    await AsyncStorage.removeItem(EVENTS_CACHE_KEY);
  } catch (e) { }
};

// Chunked caching for designs (large payloads → split to stay under limits)
export const setCachedDesing = async designs => {
  try {
    const chunks = [];
    for (let i = 0; i < designs.length; i += CHUNK_SIZE) {
      chunks.push(designs.slice(i, i + CHUNK_SIZE));
    }

    for (let i = 0; i < chunks.length; i++) {
      await AsyncStorage.setItem(
        `${DESIGNS_CHUNK_PREFIX}${i}`,
        JSON.stringify(chunks[i]),
      );
    }

    await AsyncStorage.setItem(
      DESIGNS_META_KEY,
      JSON.stringify({ totalChunks: chunks.length }),
    );

    await AsyncStorage.removeItem('cached_designs');
  } catch (e) {
    console.log('Failed to cache designs (chunked)', e);
  }
};

export const getCachedDesign = async () => {
  try {
    const metaStr = await AsyncStorage.getItem(DESIGNS_META_KEY);
    if (!metaStr) return null;

    const meta = JSON.parse(metaStr);
    const allDesigns = [];

    for (let i = 0; i < meta.totalChunks; i++) {
      const chunkStr = await AsyncStorage.getItem(`${DESIGNS_CHUNK_PREFIX}${i}`);
      if (chunkStr) {
        const chunk = JSON.parse(chunkStr);
        allDesigns.push(...chunk);
      }
    }

    return allDesigns;
  } catch (e) {
    console.log('Failed to get cached designs (chunked)', e);
    return null;
  }
};

export const clearCachedDesing = async () => {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const chunkKeys = keys.filter(
      k => k.startsWith(DESIGNS_CHUNK_PREFIX) || k === DESIGNS_META_KEY,
    );
    await AsyncStorage.multiRemove(chunkKeys);
    await AsyncStorage.removeItem('cached_designs');
  } catch (e) {
    console.log('Failed to clear cached designs', e);
  }
};

// Chunked caching for items (large payloads → split to stay under limits)
export const setCachedItem = async items => {
  try {
    const chunks = [];
    for (let i = 0; i < items.length; i += CHUNK_SIZE) {
      chunks.push(items.slice(i, i + CHUNK_SIZE));
    }

    for (let i = 0; i < chunks.length; i++) {
      await AsyncStorage.setItem(
        `${ITEM_CHUNK_PREFIX}${i}`,
        JSON.stringify(chunks[i]),
      );
    }

    await AsyncStorage.setItem(
      ITEM_META_KEY,
      JSON.stringify({ totalChunks: chunks.length }),
    );

    await AsyncStorage.removeItem('cached_items');
  } catch (e) {
    console.log('Failed to cache items (chunked)', e);
  }
};

export const getCachedItem = async () => {
  try {
    const metaStr = await AsyncStorage.getItem(ITEM_META_KEY);
    if (!metaStr) return null;

    const meta = JSON.parse(metaStr);
    const allItems = [];

    for (let i = 0; i < meta.totalChunks; i++) {
      const chunkStr = await AsyncStorage.getItem(`${ITEM_CHUNK_PREFIX}${i}`);
      if (chunkStr) {
        const chunk = JSON.parse(chunkStr);
        allItems.push(...chunk);
      }
    }

    return allItems;
  } catch (e) {
    console.log('Failed to get cached items (chunked)', e);
    return null;
  }
};

export const clearCachedItem = async () => {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const chunkKeys = keys.filter(
      k => k.startsWith(ITEM_CHUNK_PREFIX) || k === ITEM_META_KEY,
    );
    await AsyncStorage.multiRemove(chunkKeys);
    await AsyncStorage.removeItem('cached_items');
  } catch (e) {
    console.log('Failed to clear cached items', e);
  }
};

// ════════════════════════ DATABASE (expo-sqlite, async API) ════════════════

// A single shared connection promise. Using a promise (not a raw value)
// guarantees that even if many functions call getDb() at the same moment on
// first launch, the database is opened + schema-created exactly once.
let dbPromise = null;

async function openAndPrepare() {
  const db = await SQLite.openDatabaseAsync(DB_NAME);

  // WAL = better concurrency (UI can read while a sync writes in background).
  await db.execAsync('PRAGMA journal_mode = WAL;');

  // Base schema. execAsync runs the whole block; safe to call every launch.
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS enquiries (
      local_id TEXT PRIMARY KEY NOT NULL,
      server_id INTEGER,
      user_id INTEGER NOT NULL,
      party_name TEXT,
      address TEXT,
      gst_no TEXT,
      design_requirement TEXT,
      design_name TEXT,
      qty_required TEXT,
      price TEXT,
      colour_requirement TEXT,
      contact_name TEXT,
      designation TEXT,
      mobile TEXT,
      email TEXT,
      front_img TEXT,
      back_img TEXT,
      card_front_uri TEXT,
      reference_photos TEXT,
      scanned_from_card INTEGER DEFAULT 0,
      sync_status TEXT NOT NULL DEFAULT 'pending',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      event_code TEXT,
      design_dsn_code TEXT,
      design_dsn_name TEXT,
      is_deleted INTEGER DEFAULT 0
    );
  `);

  // Lightweight migrations for older installs that predate these columns.
  // ALTER ... ADD COLUMN throws if the column already exists → ignore.
  await addColumnIfMissing(db, 'event_code', 'TEXT');
  await addColumnIfMissing(db, 'design_dsn_code', 'TEXT');
  await addColumnIfMissing(db, 'design_dsn_name', 'TEXT');

  return db;
}

async function addColumnIfMissing(db, column, type) {
  try {
    await db.execAsync(`ALTER TABLE enquiries ADD COLUMN ${column} ${type};`);
    console.log(`${column} column added`);
  } catch (e) {
    // Column already exists — expected on every launch after the first.
  }
}

async function getDb() {
  if (!dbPromise) {
    dbPromise = openAndPrepare();
  }
  return dbPromise;
}

// Initialize database + warm the event/design caches.
// Call once near app start (you already call this from the screen).
export async function initDb(token, prptype) {
  await getDb(); // ensures the schema is ready

  // Fetch and cache events
  if (token && prptype) {
    try {
      const yearno = getCurrentFinancialYear();
      const response = await api.get(`${API}/api/getevent`, {
        params: { prptype, yearno },
        headers: { Authorization: `Bearer ${token}` },
      });
      const events = response.data.data;
      if (events && events.length) {
        await setCachedEvents(events);
        console.log('Events cached during initDb');
      }
    } catch (error) {
      console.log('Failed to fetch events during initDb', error.message);
    }
  }

  // Fetch and cache designs
  if (token && prptype) {
    try {
      const yearno = getCurrentFinancialYear();
      const q = '';
      const response = await api.get(`${API}/api/designs/search`, {
        params: { q, prptype, yearno },
        headers: { Authorization: `Bearer ${token}` },
      });
      const allDesigns = response.data.data;
      if (allDesigns && allDesigns.length) {
        await setCachedDesing(allDesigns);
        console.log('Designs cached during initDb', allDesigns.length);
      }
    } catch (error) {
      console.log('Failed to fetch Designs during initDb', error.message);
    }
  }

  // Fetch and cache Item
  if (token && prptype) {
    try {
      const yearno = getCurrentFinancialYear();
      const q = '';
      const response = await api.get(`${API}/api/designs/search`, {
        params: { q, prptype: 'K', yearno },
        headers: { Authorization: `Bearer ${token}` },
      });
      const allItems = response.data.data;
      if (allItems && allItems.length) {
        await setCachedItem(allItems);
        console.log('Items cached during initDb', allItems.length);
      }
    } catch (error) {
      console.log('Failed to fetch Designs during initDb', error.message);
    }
  }
}

// Unique local id for offline rows
export function generateLocalId() {
  return `ENQ_${Date.now()}_${Math.floor(Math.random() * 1000000)}`;
}

// Insert a new enquiry → returns the local_id
export async function insertEnquiry(enquiry) {
  const db = await getDb();
  const now = Date.now();
  const localId = enquiry.local_id || generateLocalId();

  await db.runAsync(
    `INSERT INTO enquiries (
      local_id, user_id, party_name, address, gst_no,
      design_requirement, design_name, qty_required, price,
      colour_requirement, contact_name, designation, mobile, email,
      front_img, back_img, card_front_uri, reference_photos,
      scanned_from_card, sync_status, created_at, updated_at,
      event_code, design_dsn_code, design_dsn_name
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      localId,
      enquiry.user_id,
      enquiry.party_name || '',
      enquiry.address || '',
      enquiry.gst_no || '',
      enquiry.design_requirement || '',
      enquiry.design_name || '',
      enquiry.qty_required || '',
      enquiry.price || '',
      enquiry.colour_requirement || '',
      enquiry.contact_name || '',
      enquiry.designation || '',
      enquiry.mobile || '',
      enquiry.email || '',
      enquiry.front_img || '',
      enquiry.back_img || '',
      enquiry.card_front_uri || '',
      JSON.stringify(enquiry.reference_photos || []),
      enquiry.scanned_from_card ? 1 : 0,
      'pending',
      now,
      now,
      enquiry.event_code || '',
      enquiry.design_dsn_code || '',
      enquiry.design_dsn_name || '',
    ],
  );

  return localId;
}

// Enquiries still needing to be pushed to the server
export async function getPendingEnquiries() {
  const db = await getDb();
  return db.getAllAsync(
    `SELECT * FROM enquiries
     WHERE sync_status IN ('pending','failed') AND is_deleted = 0`,
  );
}

// All non-deleted enquiries, newest first
export async function getAllEnquiries() {
  const db = await getDb();
  return db.getAllAsync(
    `SELECT * FROM enquiries
     WHERE is_deleted = 0
     ORDER BY created_at DESC`,
  );
}

export async function markSynced(localId, serverId) {
  const db = await getDb();
  await db.runAsync(
    `UPDATE enquiries
     SET server_id = ?, sync_status = 'synced', updated_at = ?
     WHERE local_id = ?`,
    [serverId, Date.now(), localId],
  );
}

export async function markFailed(localId) {
  const db = await getDb();
  await db.runAsync(
    `UPDATE enquiries
     SET sync_status = 'failed', updated_at = ?
     WHERE local_id = ?`,
    [Date.now(), localId],
  );
}

export async function markSyncing(localId) {
  const db = await getDb();
  await db.runAsync(
    `UPDATE enquiries SET sync_status = 'syncing' WHERE local_id = ?`,
    [localId],
  );
}

// Edit a row locally and re-queue it for sync
export const updateEnquiryLocally = async (localId, updatedData) => {
  const db = await getDb();
  const fields = [
    'party_name',
    'address',
    'gst_no',
    'design_requirement',
    'qty_required',
    'price',
    'colour_requirement',
    'contact_name',
    'designation',
    'mobile',
    'email',
    'front_img',
    'back_img',
    'card_front_uri',
    'scanned_from_card',
    'event_code',
    'design_dsn_name',
    'design_dsn_code',
  ];

  const setClause = fields.map(f => `${f} = ?`).join(', ');
  const fieldValues = fields.map(f => updatedData[f] ?? null);

  await db.runAsync(
    `UPDATE enquiries
     SET ${setClause}, sync_status = 'pending', updated_at = ?
     WHERE local_id = ?`,
    [...fieldValues, Date.now(), localId],
  );
};

export default getDb;
