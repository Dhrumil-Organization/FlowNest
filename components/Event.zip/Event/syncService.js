// syncService.js
// ────────────────────────────────────────────────────────────────────────────
// Pushes locally-saved (offline) enquiries to Laravel once connectivity returns.
// Call syncPendingEnquiries() on: app foreground, connectivity restored,
// and right after a successful manual save while online.
//
// EXPO version — connectivity via expo-network (replaces @react-native-community/netinfo).
//
// Install:
//   npx expo install expo-network
// ────────────────────────────────────────────────────────────────────────────

import * as Network from 'expo-network';
import { Platform } from 'react-native';
import api from './api';
import { API } from '../../common/API/dynamicAPI';
import { getPendingEnquiries, markSynced, markFailed, markSyncing } from './db';

let isSyncing = false; // guard against overlapping sync runs

const API_FIELDS = [
  'party_name',
  'address',
  'gst_no',
  'design_requirement',
  'design_name',
  'qty_required',
  'price',
  'colour_requirement',
  'contact_name',
  'designation',
  'mobile',
  'email',
  'front_img',
  'back_img',
  'card_front_uri',
  'scanned_from_card',
  'event_code',
  'design_dsn_code',
  'design_dsn_name',
];

// Safe FormData logger (won't crash on null values)
const logFormData = formData => {
  if (!formData?._parts) return;
  formData._parts.forEach(([key, value]) => {
    if (value && typeof value === 'object' && value.uri) {
      console.log(`  ${key} = [File: ${value.uri}]`);
    } else {
      console.log(`  ${key} = ${value}`);
    }
  });
};

async function hasConnectivity() {
  const state = await Network.getNetworkStateAsync();
  return !!(state?.isConnected && state?.isInternetReachable !== false);
}

export async function syncPendingEnquiries(token, yearno, prptype) {
  if (isSyncing) return;
  isSyncing = true;

  try {
    if (!(await hasConnectivity())) return;

    const pending = await getPendingEnquiries();

    for (const enquiry of pending) {
      try {
        const formData = new FormData();

        // back_img → file (only if present)
        if (enquiry.back_img && enquiry.back_img.trim()) {
          const fileName = enquiry.back_img.split('/').pop() || 'card.jpg';
          formData.append('back_img', {
            uri:
              Platform.OS === 'ios'
                ? enquiry.back_img.replace('file://', '')
                : enquiry.back_img,
            name: fileName,
            type: 'image/jpeg',
          });
        }

        // text fields
        API_FIELDS.forEach(key => {
          if (key === 'back_img') return;
          const value = enquiry[key];
          let finalValue = value;
          if (key === 'scanned_from_card') finalValue = value ? 1 : 0;
          formData.append(key, value !== null && value !== undefined ? finalValue : '');
        });

        formData.append('prptype', prptype);
        formData.append('yearno', yearno);
        formData.append('front_img_path', enquiry.front_img || '');
        formData.append('back_img_path', enquiry.back_img || '');
        formData.append('party_name ', enquiry.party_name || '');
        formData.append('local_id', enquiry.local_id || '');
        formData.append('design_dsn_code', enquiry.design_dsn_code || '');
        formData.append('design_dsn_name', enquiry.design_dsn_name || '');

        await markSyncing(enquiry.local_id);
        logFormData(formData);

        const res = await api.post(`${API}/api/enquiries`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        });

        await markSynced(enquiry.local_id, res.data.id);
      } catch (err) {
        console.log('Sync failed for', enquiry.local_id, err?.message);
        await markFailed(enquiry.local_id);
      }
    }
  } finally {
    isSyncing = false;
  }
}

export async function syncShowEnquiries(id, token, yearno, prptype) {
  try {
    const res = await api.get(
      `${API}/api/enquiries/${id}?prptype=${prptype}&yearno=${yearno}`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    return res.data;
  } catch (err) {
    console.log('show STATUS =>', err?.response?.status);
    console.log('show DATA =>', err?.response?.data);
    throw err;
  }
}

export async function deleteEnquiries(id, token, yearno, prptype) {
  try {
    const res = await api.delete(
      `${API}/api/enquiries/${id}?prptype=${prptype}&yearno=${yearno}`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    return res.data;
  } catch (err) {
    console.log('delete STATUS =>', err?.response?.status);
    console.log('delete DATA =>', err?.response?.data);
    throw err;
  }
}

/**
 * Auto-sync whenever connectivity is restored.
 * Call once near app startup, passing a callback that triggers your sync.
 * Returns a subscription — call subscription.remove() to stop listening.
 */
export function registerSyncListener(callback) {
  return Network.addNetworkStateListener(state => {
    if (state.isConnected && state.isInternetReachable !== false) {
      callback?.();
    }
  });
}

/**
 * Update an existing enquiry on the server (multipart, Laravel _method=PUT).
 */
export async function updateEnquiries(id, token, yearno, prptype, fpayload) {
  if (isSyncing) return;
  isSyncing = true;

  try {
    if (!(await hasConnectivity())) return;

    try {
      const formData = new FormData();

      if (fpayload.back_img && fpayload.back_img.trim()) {
        const fileName = fpayload.back_img.split('/').pop() || 'card.jpg';
        formData.append('back_img', {
          uri:
            Platform.OS === 'ios'
              ? fpayload.back_img.replace('file://', '')
              : fpayload.back_img,
          name: fileName,
          type: 'image/jpeg',
        });
      }

      API_FIELDS.forEach(key => {
        if (key === 'back_img') return;
        const value = fpayload[key];
        let finalValue = value;
        if (key === 'scanned_from_card') finalValue = value ? 1 : 0;
        formData.append(key, value !== null && value !== undefined ? finalValue : '');
      });

      formData.append('prptype', prptype);
      formData.append('yearno', yearno);
      formData.append('front_img_path', fpayload.front_img || fpayload.front_img_path || '');
      formData.append('back_img_path', fpayload.back_img || fpayload.back_img_path || '');
      formData.append('party_name ', fpayload.party_name || '');
      formData.append('local_id', fpayload.local_id || '');
      formData.append('_method', 'PUT');
      formData.append('design_dsn_code', fpayload.design_dsn_code || '');
      formData.append('design_dsn_name', fpayload.design_dsn_name || '');

      await markSyncing(fpayload.local_id);
      logFormData(formData);

      const res = await api.post(
        `${API}/api/enquiries/${id}?prptype=${prptype}&yearno=${yearno}`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: `Bearer ${token}`,
          },
        },
      );

      await markSynced(fpayload.local_id, res.data.id);
    } catch (err) {
      console.log('Update failed for', fpayload.local_id, err?.message);
      await markFailed(fpayload.local_id);
    }
  } finally {
    isSyncing = false;
  }
}
