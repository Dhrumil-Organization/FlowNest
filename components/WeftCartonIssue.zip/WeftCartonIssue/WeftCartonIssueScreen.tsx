import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
    View, Text, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator, Modal,
    KeyboardAvoidingView, Platform, RefreshControl, SafeAreaView, useWindowDimensions, Keyboard,
} from 'react-native';
import Icon from '@expo/vector-icons/MaterialIcons';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { showSuccess, showError } from '@/common/utils/snackbar';
import HeaderBarwithBack from '@/components/Header';
import SearchableDropdown from '@/Shared/SearchableDropdown';
import { fetchAllPropertyData, fetchAllYeardata } from '../../common/API/Functions';

import { s, C, tagStyle } from './styles';
import * as api from './api';
import { f2, r3, toYmd, toDmy, ymdShow, isToday, makeClientRef, parseCartonQr } from './helpers';
import LineFields, { Beam, LineValue } from './components/LineFields';
import ScannerModal from './components/ScannerModal';
import EditLineSheet, { EditableLine } from './components/EditLineSheet';

type Props = {
    token: string;
    prpCode: string;          // selected property (same as FormState.values.PrpCode today)
    yearNo: string | number;  // selected financial year
    stkType: string;          // selected stock type
    expProdQtyType?: string;  // '1' for new issue mode, '0' otherwise (same rule as the old drawer)
    onClose?: () => void;
};

type Carton = {
    CartNo: string; TranType: any; PUId: any; PSrNo: any; PSubSr: any;
    ItmCode: string; ItmName: string; MerCode: any; MerName: string; GrdCode: any; GrdName: string;
    ShdCode: any; ShdName: string; Denier: number; Chees: number; Wt: number; MItmCode: string;
    BalUnknown?: boolean; // QR without chees (short label): balance is not known on the device
};

const emptyLine: LineValue = { beam: null, dsn: null, rsr: null };

const WeftCartonIssueScreen = ({ token, prpCode, yearNo, stkType, expProdQtyType = '1', onClose }: Props) => {
    /* ---------------- header ---------------- */
    const [date, setDate] = useState(new Date());
    const [shift, setShift] = useState(1);
    const [datePicker, setDatePicker] = useState(false);

    // Property / financial year filters (same selection flow as the old WftIssue screen).
    const [propertyList, setPropertyList] = useState<any[]>([]);
    const [yearList, setYearList] = useState<any[]>([]);
    const [selectedPrpCode, setSelectedPrpCode] = useState(prpCode || '');
    const [selectedYearNo, setSelectedYearNo] = useState(yearNo || '');
    const [selectedProperty, setSelectedProperty] = useState<any>(null);
    const [selectedYear, setSelectedYear] = useState<any>(null);
    const [filterOpen, setFilterOpen] = useState(false);
    const [filterDateType, setFilterDateType] = useState<'from' | 'to' | null>(null);
    const [fromDate, setFromDate] = useState(new Date());
    const [toDate, setToDate] = useState(new Date());
    const ymd = toYmd(date);
    const dmy = toDmy(date);

    useEffect(() => {
        setSelectedPrpCode(prpCode || '');
    }, [prpCode]);

    useEffect(() => {
        setSelectedYearNo(yearNo || '');
    }, [yearNo]);

    useEffect(() => {
        if (!token) return;
        let alive = true;
        fetchAllPropertyData(token)
            .then((rows: any[]) => {
                if (!alive) return;
                const list = Array.isArray(rows) ? rows : [];
                setPropertyList(list);
                const current = list.find((p: any) => String(p.PrpCode) === String(selectedPrpCode));
                setSelectedProperty(current || null);
            })
            .catch(() => { if (alive) setPropertyList([]); });
        return () => { alive = false; };
    }, [token]);

    useEffect(() => {
        if (!token || !selectedPrpCode) {
            setYearList([]);
            setSelectedYear(null);
            return;
        }
        let alive = true;
        fetchAllYeardata(token, selectedPrpCode)
            .then((rows: any[]) => {
                if (!alive) return;
                const list = Array.isArray(rows) ? rows : [];
                setYearList(list);
                // Keep the previously selected year when it exists; otherwise
                // automatically select the first year returned by the API.
                const current = list.find((y: any) => String(y.YearNo) === String(selectedYearNo)) || list[0] || null;
                setSelectedYear(current);
                if (current?.YearNo != null) {
                    setSelectedYearNo(String(current.YearNo));
                }
            })
            .catch(() => { if (alive) setYearList([]); });
        return () => { alive = false; };
    }, [token, selectedPrpCode]);

    useEffect(() => {
        if (!selectedYearNo || yearList.length === 0) return;
        const current = yearList.find((y: any) => String(y.YearNo) === String(selectedYearNo));
        setSelectedYear(current || null);
    }, [selectedYearNo, yearList]);

    const activePrpCode = selectedPrpCode || prpCode;
    // No fallback to the prop year: after a property change the year stays empty until that
    // property's year list arrives, so nothing is fetched with a mismatched property/year.
    const activeYearNo = selectedYearNo;

    const handlePropertyChange = (item: any) => {
        const next = item?.PrpCode || '';
        setSelectedPrpCode(next);
        setSelectedProperty(item || null);
        setSelectedYearNo('');
        setSelectedYear(null);
    };

    const handleYearChange = (item: any) => {
        setSelectedYearNo(item?.YearNo || '');
        setSelectedYear(item || null);
    };

    // Browse date is a real filter. Keep the selected date in all date states
    // used by the Beams browse API so changing it immediately refreshes data.
    const handleBrowseDateChange = (value: Date) => {
        const selected = new Date(value);
        selected.setHours(0, 0, 0, 0);
        setDate(selected);
        setFromDate(selected);
        setToDate(selected);
        setDatePicker(false);
    };


    const [tab, setTab] = useState<'issue' | 'beams'>('issue');
    const { width: screenWidth } = useWindowDimensions();
    const isMobile = screenWidth < 700;

    /* ---------------- master data ---------------- */
    const [beams, setBeams] = useState<Beam[]>([]);
    const [beamsLoading, setBeamsLoading] = useState(false);

    useEffect(() => {
        if (tab !== 'issue' || !activePrpCode || !activeYearNo) return;
        let alive = true;
        setBeamsLoading(true);
        api.fetchBeams(token, activePrpCode, activeYearNo, dmy)
            .then(list => alive && setBeams(list.map((b: any) => ({ ...b, UId: b.UId ?? b.BeamUId, BeamNo: b.BeamNo }))))
            .finally(() => alive && setBeamsLoading(false));
        return () => { alive = false; };
    }, [tab, token, activePrpCode, activeYearNo, dmy]);

    /* ---------------- carton ---------------- */
    const [mode, setMode] = useState<'scan' | 'manual'>('scan');
    const [scanErr, setScanErr] = useState('');
    const [scannerOpen, setScannerOpen] = useState(false);
    const [search, setSearch] = useState('');
    const [results, setResults] = useState<Carton[]>([]);
    const [searching, setSearching] = useState(false);
    const searchCache = useRef<Map<string, Carton[]>>(new Map());
    const lastSearchRef = useRef('');

    const [carton, setCarton] = useState<Carton | null>(null);
    const [cartonLines, setCartonLines] = useState<any[]>([]);
    const [cartonDone, setCartonDone] = useState(false); // fully issued
    const [loadingCarton, setLoadingCarton] = useState(false);
    const [startBal, setStartBal] = useState<{ chees: number; wt: number } | null>(null); // balance when the carton was loaded
    const [issuedNow, setIssuedNow] = useState<{ key: string; beam: string; dsn: string; chees: number; wt: number }[]>([]);

    /* ---------------- entry ---------------- */
    const [line, setLine] = useState<LineValue>(emptyLine);
    const [chees, setChees] = useState('');
    const [wt, setWt] = useState('');
    const [wtTouched, setWtTouched] = useState(false);
    const [formErr, setFormErr] = useState('');
    const [saving, setSaving] = useState(false);
    const [preview, setPreview] = useState<{ IssNo: string } | null | undefined>(undefined);
    const clientRef = useRef<string | null>(null); // kept across retries of the same entry

    /* ---------------- beams tab ---------------- */
    const [issues, setIssues] = useState<any[]>([]);
    const [issuesLoading, setIssuesLoading] = useState(false);

    /* ---------------- edit ---------------- */
    const [editLine, setEditLine] = useState<EditableLine | null>(null);

    /* ======================================================================
       Carton load (scan / manual pick)
       ====================================================================== */
    const setCartonFrom = (c: Carton) => {
        setCarton(c);
        setStartBal(c.BalUnknown ? null : { chees: Number(c.Chees) || 0, wt: Number(c.Wt) || 0 });
        setCartonLines([]);
        setCartonDone(false);
        setIssuedNow([]);
        resetEntry();
    };

    /** SCAN: same as the old screen. The QR already has the carton data; the only call made
     *  afterwards is get_item_detail_from_carton (item / merchandise / shade / grade names). */
    const loadScanned = useCallback(async (raw: string) => {
        const q = parseCartonQr(raw);
        if (!q || !q.CartNo) {
            setScanErr('Invalid QR. Scan the carton label again.');
            return;
        }
        setScanErr('');
        setLoadingCarton(true);

        // Plain carton number (handheld scanner): nothing else to read from it, use the search API once.
        if (!q.ItmCode) {
            const r = await api.cartonBalance(token, activePrpCode, activeYearNo, q.CartNo, {});
            setLoadingCarton(false);
            if (!r.ok || !r.payload?.data) {
                setScanErr(r.message || `${q.CartNo} is not in weft stock.`);
                return;
            }
            setCartonFrom({ ...r.payload.data, BalUnknown: false });
            return;
        }

        const cheesQr = parseInt(String(q.Chees ?? 0), 10) || 0;
        const wtQr = Number(q.Wt) || 0;
        const base: Carton = {
            CartNo: q.CartNo, TranType: q.TranType, PUId: q.PUId, PSrNo: q.PSrNo, PSubSr: q.PSubSr,
            ItmCode: q.ItmCode, ItmName: q.ItmName || '', MerCode: q.MerCode, MerName: q.MerName || '',
            GrdCode: q.GrdCode, GrdName: q.GrdName || '', ShdCode: q.ShdCode, ShdName: q.ShdName || '',
            Denier: Number(q.Denier) || 0, Chees: cheesQr, Wt: wtQr, MItmCode: '',
            BalUnknown: !(cheesQr > 0),
        };

        const r = await api.itemDetailFromCarton(token, activePrpCode, activeYearNo, q);
        setLoadingCarton(false);
        const d = r.ok ? r.payload?.data : null;
        if (d) {
            base.ItmName = d.ItmName || base.ItmName;
            base.MerName = d.MerName || base.MerName;
            base.ShdName = d.ShdName || base.ShdName;
            base.GrdName = d.GrdName || base.GrdName;
            base.MItmCode = String(d.MItmCode ?? d.mitmcode ?? d.MainItmCode ?? '');
        }
        setCartonFrom(base);
    }, [token, activePrpCode, activeYearNo]);

    /** MANUAL: the search row already has everything, so selecting it needs no further call. */
    const pickManual = (c: Carton) => {
        Keyboard.dismiss();
        setScanErr('');
        setSearch('');
        setResults([]);
        setSearching(false);
        lastSearchRef.current = '';
        setCartonFrom({
            ...c,
            Chees: parseInt(String(c.Chees ?? 0), 10) || 0,
            Wt: Number(c.Wt) || 0,
            Denier: Number(c.Denier) || 0,
            BalUnknown: false,
        });
    };

    const refreshCarton = useCallback(async () => {
        if (!carton) return;
        const r = await api.cartonBalance(token, activePrpCode, activeYearNo, carton.CartNo, carton);
        if (r.ok && r.payload?.data) {
            setCarton({ ...carton, ...r.payload.data, BalUnknown: false });
            setCartonLines(r.payload.lines || []);
            setCartonDone(false);
        } else {
            // No balance left: keep the card, show the lines, offer next carton.
            setCarton({ ...carton, Chees: 0, Wt: 0, BalUnknown: false });
            setCartonLines(r.payload?.lines || []);
            setCartonDone(true);
        }
    }, [carton, token, activePrpCode, activeYearNo]);

    const clearCarton = () => {
        setCarton(null);
        setCartonLines([]);
        setCartonDone(false);
        setStartBal(null);
        setIssuedNow([]);
        resetEntry();
    };

    /* Scan <-> Manual: never carry one mode's carton / search into the other. */
    const switchMode = (m: 'scan' | 'manual') => {
        if (m === mode) return;
        setMode(m);
        clearCarton();
        setScanErr('');
        setSearch('');
        setResults([]);
        setSearching(false);
        lastSearchRef.current = '';
    };

    /* Property / year changed: the carton, search results and beams belonged to the old selection. */
    const selectionInit = useRef(true);
    useEffect(() => {
        if (selectionInit.current) { selectionInit.current = false; return; }
        clearCarton();
        searchCache.current.clear();
        setScanErr('');
        setSearch('');
        setResults([]);
        setSearching(false);
        lastSearchRef.current = '';
    }, [activePrpCode, activeYearNo]);

    /* manual search (debounced + cached to keep typing fast) */
    useEffect(() => {
        if (tab !== 'issue' || mode !== 'manual' || !activePrpCode || !activeYearNo) return;
        const q = search.trim();

        if (q.length < 2) {
            setSearching(false);
            setResults([]);
            lastSearchRef.current = '';
            return;
        }

        if (q === lastSearchRef.current) return;
        const cached = searchCache.current.get(`${activePrpCode}|${activeYearNo}|${q}`);
        if (cached) {
            lastSearchRef.current = q;
            setResults(cached);
            return;
        }

        const t = setTimeout(async () => {
            lastSearchRef.current = q;
            setSearching(true);
            const r = await api.searchCartons(token, activePrpCode, activeYearNo, q);
            const next = r.ok ? api.listOf({ data: r.payload?.data }) : [];
            searchCache.current.set(`${activePrpCode}|${activeYearNo}|${q}`, next);
            setResults(next);
            setSearching(false);
        }, 300);
        return () => clearTimeout(t);
    }, [search, mode, tab, token, activePrpCode, activeYearNo]);

    /* ======================================================================
       Entry
       ====================================================================== */
    function resetEntry() {
        setLine(emptyLine);
        setChees('');
        setWt('');
        setWtTouched(false);
        setFormErr('');
        setPreview(undefined);
        clientRef.current = null;
    }

    // any change to the entry means a new request id
    const touchEntry = () => { clientRef.current = null; setFormErr(''); };

    const onChees = (v: string) => {
        touchEntry();
        setChees(v);
        if (!carton || wtTouched) return;
        const n = parseInt(v, 10);
        if (!(n > 0) || carton.Chees <= 0) { setWt(''); return; }
        setWt(n >= carton.Chees ? f2(carton.Wt) : f2((carton.Wt / carton.Chees) * n)); // last chees takes exact balance
    };

    /* "Adds to IssNo 0045" / "New issue" preview */
    useEffect(() => {
        setPreview(undefined);
        if (!line.beam || !line.dsn) return;
        let alive = true;
        api.findIssue(token, activePrpCode, ymd, line.beam.UId, line.dsn.DsnCode).then(r => {
            if (alive) setPreview(r.payload?.data || null);
        });
        return () => { alive = false; };
    }, [line.beam?.UId, line.dsn?.DsnCode, ymd]);

    const addBeam = async () => {
        if (saving || !carton) return;
        const ch = parseInt(chees, 10);
        const w = r3(parseFloat(wt));

        if (!line.beam) return setFormErr('Select a beam.');
        if (!line.dsn) return setFormErr('Select a design.');
        if (!line.rsr) return setFormErr('Select the weft position (recipe SrNo).');
        if (!(ch > 0)) return setFormErr('Chees must be a whole number above 0.');
        if (!(w > 0)) return setFormErr('Weight must be above 0.');
        if (!carton.BalUnknown && ch > carton.Chees) return setFormErr(`Only ${carton.Chees} chees left in ${carton.CartNo}.`);
        if (!carton.BalUnknown && w > carton.Wt + 0.0005) return setFormErr(`Only ${f2(carton.Wt)} kg left in ${carton.CartNo}.`);

        if (!clientRef.current) clientRef.current = makeClientRef();
        setSaving(true);

        const exp = await api.fetchExpProdQty(token, {
            prpcode: activePrpCode, yearno: activeYearNo, wt: w, itmcode: carton.ItmCode, shdcode: carton.ShdCode,
            dsnrcpsrno: line.rsr, beamuid: line.beam.UId, dsncode: line.dsn.DsnCode,
        });

        const r = await api.saveLine(token, {
            prpcode: activePrpCode, yearno: activeYearNo, IssDate: ymd, Shift: shift, StkType: stkType,
            BeamUId: line.beam.UId, DsnCode: line.dsn.DsnCode, DsnRcpSrNo: line.rsr,
            ExpProdQty: exp, ExpProdQtyType: expProdQtyType,
            Chees: ch, Wt: w, ClientRefId: clientRef.current,
            CartNo: carton.CartNo, TranType: carton.TranType, PUId: carton.PUId, PSrNo: carton.PSrNo, PSubSr: carton.PSubSr,
            ItmCode: carton.ItmCode, MerCode: carton.MerCode, GrdCode: carton.GrdCode, ShdCode: carton.ShdCode, Denier: carton.Denier,
        });
        setSaving(false);

        if (!r.ok) {
            // NETWORK: keep clientRef so the retry cannot create a second line
            setFormErr(r.message || 'Could not save. Try again.');
            if (r.errorCode === 'BALANCE_EXCEEDED' || r.errorCode === 'CARTON_EMPTY') refreshCarton();
            return;
        }

        showSuccess?.(`${line.beam.BeamNo}: ${r.message}`);
        setIssuedNow(prev => [...prev, {
            key: `${Date.now()}`, beam: line.beam?.BeamNo || '', dsn: `${line.dsn?.DsnCode ?? ''}`, chees: ch, wt: w,
        }]);
        // Update the balance locally (no extra API call after saving).
        if (!carton.BalUnknown) {
            const left = Math.max(0, carton.Chees - ch);
            setCarton({ ...carton, Chees: left, Wt: Math.max(0, r3(carton.Wt - w)) });
            if (left <= 0) setCartonDone(true);
        }
        resetEntry();
    };

    /* ======================================================================
       Delete
       ====================================================================== */
    const confirmDeleteLine = (l: any) => {
        Alert.alert(
            'Delete this line?',
            `${l.CartNo}: ${l.Chees} chees, ${f2(l.Qty)} kg from ${l.BeamNo || 'beam'} (IssNo ${l.IssNo}).\nStock goes back to the carton.`,
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Delete', style: 'destructive', onPress: async () => {
                        const r = await api.deleteLine(token, { prpcode: activePrpCode, yearno: activeYearNo, uid: l.UId, srno: l.SrNo, subsr: l.SubSr });
                        if (!r.ok) { showError?.(r.message || 'Could not delete.'); return; }
                        const hd = r.payload?.data?.header_deleted ? ` IssNo ${l.IssNo} had no lines left and was removed.` : '';
                        showSuccess?.(`Line deleted.${hd}`);
                        afterChange();
                    },
                },
            ],
        );
    };

    const confirmDeleteIssue = (iss: any) => {
        Alert.alert(
            `Delete IssNo ${iss.IssNo}?`,
            `${iss.BeamNo} / ${iss.DsnCode}, ${ymdShow(iss.IssDate)}. All carton lines are removed and stock goes back.`,
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Delete issue', style: 'destructive', onPress: async () => {
                        const r = await api.deleteIssue(token, { prpcode: activePrpCode, yearno: activeYearNo, uid: iss.UId });
                        if (!r.ok) { showError?.(r.message || 'Could not delete.'); return; }
                        showSuccess?.(`IssNo ${iss.IssNo} deleted.`);
                        afterChange();
                    },
                },
            ],
        );
    };

    /* ======================================================================
       Beams tab
       ====================================================================== */
    const loadIssues = useCallback(async () => {
        setIssuesLoading(true);
        const r = await api.issueList(token, {
            prpcode: activePrpCode,
            yearno: activeYearNo,
            fromdate: toYmd(fromDate),
            todate: toYmd(toDate),
        });
        setIssuesLoading(false);
        setIssues(r.ok ? api.listOf({ data: r.payload?.data }) : []);
    }, [fromDate, toDate, token, activePrpCode, activeYearNo]);

    useEffect(() => { if (tab === 'beams') loadIssues(); }, [tab, loadIssues]);

    const afterChange = () => {
        if (carton) refreshCarton();
        if (tab === 'beams') loadIssues();
    };

    /* ======================================================================
       Render helpers
       ====================================================================== */

    const LineRow = ({ l }: { l: any }) => (
        <View style={s.line}>
            <View style={{ flex: 1 }}>
                <Text style={s.lineTitle}>{l.BeamNo || `Beam ${l.BeamUId}`} / {l.DsnCode}</Text>
                <Text style={s.lineSub}>{l.Chees} chees, {f2(l.Qty)} kg, IssNo {l.IssNo} ({ymdShow(l.IssDate)}), SrNo {l.SrNo}.{l.SubSr}</Text>
                {l.Locked && <Text style={s.lockText}>Return or production entry exists. Locked.</Text>}
            </View>
            <TouchableOpacity style={[s.iconBtn, l.Locked && { opacity: 0.4 }]} disabled={l.Locked} onPress={() => setEditLine(l)} accessibilityLabel="Modify line">
                <Icon name="edit" size={18} color={C.ink2} />
            </TouchableOpacity>
            <TouchableOpacity style={[s.iconBtn, l.Locked && { opacity: 0.4 }]} disabled={l.Locked} onPress={() => confirmDeleteLine(l)} accessibilityLabel="Delete line">
                <Icon name="delete-outline" size={18} color={C.ink2} />
            </TouchableOpacity>
        </View>
    );

    /* ---------------- Issue tab ---------------- */
    const cartonReady = !!carton;
    const fullyIssued = !!carton && (cartonDone || (!carton.BalUnknown && carton.Chees <= 0));

    // Progress bar: issued (before) | this entry | still available.
    const entryChees = Math.max(0, parseInt(chees, 10) || 0);
    const bar = (() => {
        if (!carton || carton.BalUnknown || !startBal || startBal.chees <= 0) return null;
        const total = startBal.chees;
        const issued = Math.max(0, total - carton.Chees);
        const entry = Math.min(entryChees, carton.Chees);
        const avail = Math.max(0, carton.Chees - entry);
        return { issued, entry, avail };
    })();

    const renderIssue = () => (
        <>
            <View style={s.seg}>
                {(['scan', 'manual'] as const).map(m => (
                    <TouchableOpacity key={m} style={[s.segBtn, mode === m && s.segBtnOn]} onPress={() => switchMode(m)} activeOpacity={0.8}>
                        <Icon name={m === 'scan' ? 'qr-code-scanner' : 'search'} size={18} color={mode === m ? C.primary : C.ink2} />
                        <Text style={[s.segText, mode === m && s.segTextOn]}>{m === 'scan' ? 'Scan carton' : 'Select manually'}</Text>
                    </TouchableOpacity>
                ))}
            </View>

            {/* SCAN: only before a carton is chosen */}
            {mode === 'scan' && !cartonReady && (
                <View style={s.scanZone}>
                    <View style={s.scanIconWrap}><Icon name="qr-code-scanner" size={32} color={C.primary} /></View>
                    <Text style={s.scanTitle}>Scan carton label</Text>
                    <Text style={s.scanText}>Point the camera at the QR on the carton. Its balance appears here, then issue it to one beam after another.</Text>
                    <TouchableOpacity
                        style={[s.btn, s.btnPrimary, { minWidth: 190 }]}
                        onPress={() => setScannerOpen(true)}
                        accessibilityLabel="Open camera scanner"
                    >
                        <Icon name="photo-camera" size={20} color="#fff" />
                        <Text style={s.btnPrimaryText}>Open scanner</Text>
                    </TouchableOpacity>
                </View>
            )}

            {/* MANUAL: the search list goes away as soon as a carton is selected */}
            {mode === 'manual' && !cartonReady && (
                <View style={s.searchPanel}>
                    <Text style={s.label}>SEARCH CARTON, ITEM OR SHADE</Text>
                    <View style={s.searchWrap}>
                        <Icon name="search" size={20} color={C.ink2} />
                        <TextInput
                            style={s.searchInput}
                            placeholder="e.g. 10452 or 75D"
                            placeholderTextColor={C.ink2}
                            value={search}
                            onChangeText={setSearch}
                            autoCorrect={false}
                            autoCapitalize="characters"
                        />
                        {!!search && (
                            <TouchableOpacity onPress={() => setSearch('')} accessibilityLabel="Clear search">
                                <Icon name="cancel" size={18} color={C.ink2} />
                            </TouchableOpacity>
                        )}
                    </View>

                    {searching && <ActivityIndicator style={{ padding: 16 }} color={C.primary} />}

                    {!searching && results.length === 0 && (
                        <Text style={[s.hint, { marginTop: 10 }]}>
                            {search.trim().length < 2 ? 'Type at least 2 characters to search.' : 'No carton with balance matches.'}
                        </Text>
                    )}

                    {!searching && results.length > 0 && (
                        <ScrollView style={s.resultList} nestedScrollEnabled keyboardShouldPersistTaps="handled">
                            {results.map((c: Carton) => (
                                <TouchableOpacity
                                    key={`${c.CartNo}-${c.PUId}-${c.PSrNo}-${c.PSubSr}`}
                                    style={s.resultRow}
                                    activeOpacity={0.7}
                                    onPress={() => pickManual(c)}
                                >
                                    <View style={s.resultIcon}><Icon name="inventory-2" size={18} color={C.primary} /></View>
                                    <View style={{ flex: 1 }}>
                                        <Text style={s.lineTitle}>{c.CartNo}</Text>
                                        <Text style={s.lineSub} numberOfLines={1}>{[c.ItmName, c.ShdName, c.GrdName].filter(Boolean).join(', ')}</Text>
                                    </View>
                                    <View style={{ alignItems: 'flex-end', gap: 3 }}>
                                        <View style={s.badge}><Text style={s.badgeText}>{c.Chees} chees</Text></View>
                                        <Text style={s.lineSub}>{f2(c.Wt)} kg</Text>
                                    </View>
                                </TouchableOpacity>
                            ))}
                        </ScrollView>
                    )}
                </View>
            )}

            {!!scanErr && <View style={[s.msg, { backgroundColor: C.badSoft, marginTop: 10 }]}><Text style={[s.msgText, { color: C.bad }]}>{scanErr}</Text></View>}
            {loadingCarton && <ActivityIndicator style={{ marginTop: 16 }} color={C.primary} />}

            {!!carton && (
                <>
                    <View style={s.card}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <View style={s.cardAvatar}><Icon name="inventory-2" size={22} color={C.primary} /></View>
                            <View style={{ flex: 1 }}>
                                <Text style={s.cartNo}>{carton.CartNo}</Text>
                                <Text style={s.sub}>{mode === 'scan' ? 'Scanned carton' : 'Selected carton'}</Text>
                            </View>
                            <TouchableOpacity style={[s.btn, s.btnSm]} onPress={clearCarton} activeOpacity={0.8}>
                                <Icon name="swap-horiz" size={16} color={C.ink} />
                                <Text style={[s.btnText, s.btnSmText]}>Change</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={s.chipRow}>
                            {[carton.ItmName, carton.MerName, carton.ShdName ? `Shade ${carton.ShdName}` : '', carton.GrdName ? `Grade ${carton.GrdName}` : '']
                                .filter(Boolean)
                                .map((x, i) => <View key={i} style={s.chip}><Text style={s.chipText}>{x}</Text></View>)}
                        </View>

                        <View style={s.balRow}>
                            <View style={s.balBox}><Text style={s.balLabel}>Balance chees</Text><Text style={s.balValue}>{carton.BalUnknown ? '-' : carton.Chees}</Text></View>
                            <View style={s.balBox}><Text style={s.balLabel}>Balance weight (kg)</Text><Text style={s.balValue}>{carton.BalUnknown ? '-' : f2(carton.Wt)}</Text></View>
                        </View>

                        {!!bar && (
                            <>
                                <View style={s.progressTrack}>
                                    {bar.issued > 0 && <View style={{ flex: bar.issued, backgroundColor: C.dotUsed }} />}
                                    {bar.entry > 0 && <View style={{ flex: bar.entry, backgroundColor: C.primary }} />}
                                    {bar.avail > 0 && <View style={{ flex: bar.avail, backgroundColor: '#5FC3B5' }} />}
                                </View>
                                <View style={s.legend}>
                                    <View style={s.legendItem}><View style={[s.legendDot, { backgroundColor: C.dotUsed }]} /><Text style={s.legendText}>Issued</Text></View>
                                    <View style={s.legendItem}><View style={[s.legendDot, { backgroundColor: C.primary }]} /><Text style={s.legendText}>This entry</Text></View>
                                    <View style={s.legendItem}><View style={[s.legendDot, { backgroundColor: '#5FC3B5' }]} /><Text style={s.legendText}>Available</Text></View>
                                </View>
                            </>
                        )}
                        {carton.BalUnknown && <Text style={[s.hint, { marginTop: 10 }]}>This label has no chees count, so the balance is checked when you save.</Text>}
                    </View>

                    {(cartonLines.length > 0 || issuedNow.length > 0) && (
                        <View style={s.secRow}>
                            <Text style={s.secTitle}>Issued from this carton</Text>
                            <Text style={s.secSub}>{cartonLines.length + issuedNow.length} line{cartonLines.length + issuedNow.length === 1 ? '' : 's'}</Text>
                        </View>
                    )}
                    {cartonLines.map(l => <LineRow key={`${l.UId}-${l.SrNo}-${l.SubSr}`} l={l} />)}
                    {issuedNow.map(x => (
                        <View key={x.key} style={s.line}>
                            <View style={{ flex: 1 }}>
                                <Text style={s.lineTitle}>{x.beam} / {x.dsn}</Text>
                                <Text style={s.lineSub}>{x.chees} chees, {f2(x.wt)} kg. Edit or delete from the Beams tab.</Text>
                            </View>
                            <Icon name="check-circle" size={20} color={C.ok} />
                        </View>
                    ))}

                    {fullyIssued ? (
                        <View style={[s.msg, { backgroundColor: C.okSoft, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 }]}>
                            <Text style={[s.msgText, { color: C.ok, fontWeight: '700' }]}>Carton fully issued.</Text>
                            <TouchableOpacity style={[s.btn, s.btnSm, s.btnPrimary]} onPress={clearCarton}><Text style={[s.btnPrimaryText, s.btnSmText]}>Next carton</Text></TouchableOpacity>
                        </View>
                    ) : (
                        <View style={s.entry}>
                            <View style={[s.secRow, { marginTop: 0, alignItems: 'center' }]}>
                                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                    <View style={s.stepBadge}><Text style={s.stepBadgeText}>1</Text></View>
                                    <Text style={s.secTitle}>Issue to a beam</Text>
                                </View>
                                <Text style={s.secSub}>Saves on add</Text>
                            </View>

                            <LineFields
                                token={token} prpcode={activePrpCode} yearno={activeYearNo} stkType={stkType} dmy={dmy}
                                beams={beams} beamsLoading={beamsLoading} mitmcode={carton.MItmCode}
                                value={line} onChange={v => { touchEntry(); setLine(v); }} isMobile={isMobile}
                            />

                            <View style={[s.row2, isMobile && s.row2Mobile]}>
                                <View style={s.col}>
                                    <Text style={s.label}>CHEES</Text>
                                    <TextInput style={s.input} keyboardType="number-pad" value={chees} onChangeText={onChees} placeholder={carton.BalUnknown ? 'Chees' : `max ${carton.Chees}`} placeholderTextColor={C.ink2} />
                                </View>
                                <View style={s.col}>
                                    <Text style={s.label}>WEIGHT (KG)</Text>
                                    <TextInput style={s.input} keyboardType="decimal-pad" value={wt}
                                        onChangeText={v => { touchEntry(); setWt(v); setWtTouched(v !== ''); }} />
                                </View>
                            </View>

                            {preview !== undefined && !!line.beam && !!line.dsn && (
                                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                                    {preview
                                        ? <View style={[s.tag, tagStyle('ok').box]}><Text style={[s.tagText, tagStyle('ok').text]}>Adds to IssNo {preview.IssNo}</Text></View>
                                        : <View style={[s.tag, tagStyle('new').box]}><Text style={[s.tagText, tagStyle('new').text]}>New issue</Text></View>}
                                    <Text style={[s.hint, { marginTop: 0, flex: 1 }]}>
                                        {preview ? 'Issue for this beam and design already exists on this date.' : `First entry for this beam and design on ${ymdShow(ymd)}.`}
                                    </Text>
                                </View>
                            )}
                            {!!chees && !wtTouched && <Text style={[s.hint, { marginTop: 0, marginBottom: 8 }]}>Weight filled from average chees weight. Edit it if the scale says otherwise.</Text>}
                            {!!formErr && <View style={[s.msg, { backgroundColor: C.badSoft }]}><Text style={[s.msgText, { color: C.bad }]}>{formErr}</Text></View>}

                            <TouchableOpacity style={[s.btn, s.btnPrimary, { height: 48 }]} onPress={addBeam} disabled={saving} activeOpacity={0.85}>
                                {saving ? <ActivityIndicator color="#fff" /> : (<><Icon name="add-circle-outline" size={20} color="#fff" /><Text style={s.btnPrimaryText}>Add beam</Text></>)}
                            </TouchableOpacity>
                        </View>
                    )}
                </>
            )}

        </>
    );

    /* ---------------- Beams tab ---------------- */
    const renderBeams = () => (
        <>
            {!issuesLoading && issues.length === 0 && (
                <View style={s.empty}>
                    <View style={s.emptyIcon}><Icon name="view-agenda" size={24} color={C.ink2} /></View>
                    <Text style={s.emptyTitle}>No weft issue here</Text>
                    <Text style={s.emptyText}>Issue a carton from the Issue tab and it shows up grouped by beam.</Text>
                </View>
            )}

            {issues.map(iss => (
                <View key={iss.UId} style={s.issCard}>
                    <View style={s.issHead}>
                        <View style={{ flex: 1 }}>
                            <Text style={s.issTitle}>{iss.BeamNo || `Beam ${iss.BeamUId}`} / {iss.DsnCode}</Text>
                            <Text style={s.lineSub}>{iss.DsnName}{iss.DsnName ? ', ' : ''}IssNo {iss.IssNo}, {ymdShow(iss.IssDate)}, shift {iss.Shift}</Text>
                            <Text style={s.lineSub}>{iss.TotChees} chees, {f2(iss.TotQty)} kg</Text>
                            {iss.Locked && <Text style={s.lockText}>Return or production entry exists. Locked.</Text>}
                        </View>
                        <TouchableOpacity style={[s.btn, s.btnSm, s.btnDanger, iss.Locked && { opacity: 0.4 }]} disabled={iss.Locked} onPress={() => confirmDeleteIssue(iss)}>
                            <Text style={[s.btnDangerText, s.btnSmText]}>Delete issue</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={{ paddingHorizontal: 12, paddingBottom: 10 }}>
                        {(iss.groups || []).map((g: any) => (
                            <View key={g.SrNo}>
                                <View style={s.grpRow}>
                                    <Text style={s.grpText}>SrNo {g.SrNo}: {g.ItmName || g.ItmCode}, recipe {g.DsnRcpSrNo}</Text>
                                    <Text style={s.grpText}>{g.TotPcs} ctn, {f2(g.TotQty)} kg</Text>
                                </View>
                                {(g.lines || []).map((l: any) => (
                                    <LineRow
                                        key={`${l.UId}-${l.SrNo}-${l.SubSr}`}
                                        l={{
                                            ...l, IssNo: iss.IssNo, IssDate: iss.IssDate, BeamUId: iss.BeamUId, BeamNo: iss.BeamNo,
                                            DsnCode: iss.DsnCode, DsnName: iss.DsnName, Locked: iss.Locked,
                                            ItmCode: g.ItmCode, ShdCode: g.ShdCode,
                                        }}
                                    />
                                ))}
                            </View>
                        ))}
                    </View>
                </View>
            ))}
        </>
    );

    /* ======================================================================
       Screen
       ====================================================================== */
    return (
        <SafeAreaView style={s.screen}>
            <HeaderBarwithBack
                userName={''}
                header={'Weft Issue'}
                subHeader={'Issue and manage weft yarn for production'}
                breadcrumb={'Weft Issue'}
                SearchBar={false}
            />

            <View style={[s.criteriaTrigger, isMobile && s.criteriaTriggerMobile]}>
                <TouchableOpacity style={s.criteriaTriggerButton} activeOpacity={0.85} onPress={() => setFilterOpen(true)} accessibilityLabel="Change property and year">
                    <View style={s.criteriaTriggerIcon}>
                        <Icon name="tune" size={20} color={C.primary} />
                    </View>
                    <View style={s.criteriaTriggerTextWrap}>
                        <View style={s.critRow}>
                            <View style={s.critItem}>
                                <Text style={s.critLabel}>Property</Text>
                                <Text style={s.critValue} numberOfLines={1}>{selectedProperty?.LngName || selectedProperty?.PrpName || 'Select'}</Text>
                            </View>
                            <View style={s.critDivider} />
                            <View style={{ minWidth: 84 }}>
                                <Text style={s.critLabel}>Year</Text>
                                <Text style={s.critValue} numberOfLines={1}>{selectedYear?.YearName || selectedYear?.YearNo || 'Select'}</Text>
                            </View>
                        </View>
                        {tab === 'beams' && <Text style={s.critDates}>{toDmy(fromDate)} to {toDmy(toDate)}</Text>}
                    </View>
                    <Icon name="keyboard-arrow-right" size={22} color={C.ink2} />
                </TouchableOpacity>
            </View>

            <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
                <ScrollView
                    contentContainerStyle={[s.body, isMobile ? s.bodyMobile : s.bodyWeb]}
                    keyboardShouldPersistTaps="handled"
                    refreshControl={<RefreshControl refreshing={tab === 'beams' && issuesLoading} onRefresh={() => (tab === 'beams' ? loadIssues() : refreshCarton())} />}
                >
                    {tab === 'issue' ? renderIssue() : renderBeams()}
                </ScrollView>
            </KeyboardAvoidingView>

            <View style={s.tabs}>
                <TouchableOpacity style={[s.tab, tab === 'issue' && s.tabOn]} onPress={() => setTab('issue')}>
                    <Icon name="qr-code-scanner" size={22} color={tab === 'issue' ? C.indigo : C.ink2} />
                    <Text style={[s.tabText, tab === 'issue' && s.tabTextOn]}>Issue</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.tab, tab === 'beams' && s.tabOn]} onPress={() => setTab('beams')}>
                    <Icon name="view-agenda" size={22} color={tab === 'beams' ? C.indigo : C.ink2} />
                    <Text style={[s.tabText, tab === 'beams' && s.tabTextOn]}>Beams</Text>
                </TouchableOpacity>
            </View>

            <DateTimePickerModal
                isVisible={datePicker}
                mode="date"
                date={date}
                onConfirm={handleBrowseDateChange}
                onCancel={() => setDatePicker(false)}
            />

            <DateTimePickerModal
                isVisible={filterDateType !== null}
                mode="date"
                date={filterDateType === 'from' ? fromDate : toDate}
                maximumDate={new Date()}
                onConfirm={d => {
                    setFilterDateType(null);
                    if (filterDateType === 'from') {
                        setFromDate(d);
                        if (d > toDate) setToDate(d);
                    } else {
                        setToDate(d);
                    }
                }}
                onCancel={() => setFilterDateType(null)}
            />

            <Modal visible={filterOpen} transparent animationType="slide" onRequestClose={() => setFilterOpen(false)}>
                <View style={s.modalWrap}>
                    <View style={s.filterSheet}>
                        <View style={s.sheetHandle} />
                        <View style={s.filterSheetHeader}>
                            <Text style={s.sheetTitle}>{tab === 'beams' ? 'Filter Records' : 'Property & Year'}</Text>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
                                <TouchableOpacity onPress={() => {
                                    setSelectedPrpCode(prpCode || '');
                                    setSelectedYearNo(yearNo || '');
                                    setSelectedProperty(propertyList.find((p: any) => String(p.PrpCode) === String(prpCode)) || null);
                                    setSelectedYear(yearList.find((y: any) => String(y.YearNo) === String(yearNo)) || null);
                                    const today = new Date();
                                    setFromDate(today);
                                    setToDate(today);
                                }}>
                                    <Text style={s.filterReset}>Reset</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => setFilterOpen(false)} accessibilityLabel="Close filters">
                                    <Icon name="close" size={24} color={C.ink} />
                                </TouchableOpacity>
                            </View>
                        </View>

                        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 12 }}>
                            <View style={[s.filterFieldRow, isMobile && s.filterFieldRowMobile]}>
                                <View style={s.filterField}>
                                    <Text style={s.filterLabel}>Property</Text>
                                    <SearchableDropdown
                                        key={`filter-prp-${activePrpCode}`}
                                        data={propertyList}
                                        labelKey="LngName"
                                        valueKey="PrpCode"
                                        placeholder="Choose property..."
                                        pageSize={10}
                                        initialValue={selectedProperty}
                                        onSelect={handlePropertyChange}
                                        multiple={false}
                                        emptyMessage="No properties available"
                                    />
                                </View>

                                <View style={s.filterField}>
                                    <Text style={s.filterLabel}>Year</Text>
                                    <SearchableDropdown
                                        key={`filter-year-${activeYearNo}`}
                                        data={yearList}
                                        labelKey="YearName"
                                        valueKey="YearNo"
                                        placeholder="Choose year..."
                                        pageSize={10}
                                        initialValue={selectedYear}
                                        onSelect={handleYearChange}
                                        multiple={false}
                                        emptyMessage="No years data available"
                                    />
                                </View>
                            </View>

                            {tab === 'beams' && (
                            <View style={[s.filterFieldRow, isMobile && s.filterFieldRowMobile, { marginTop: 12 }]}>
                                <View style={s.filterField}>
                                    <Text style={s.filterLabel}>From Date</Text>
                                    <TouchableOpacity style={s.filterDateBtn} onPress={() => setFilterDateType('from')} activeOpacity={0.8}>
                                        <Icon name="calendar-today" size={17} color={C.primary} />
                                        <Text style={s.filterDateText}>{toDmy(fromDate)}</Text>
                                        <Icon name="chevron-right" size={18} color={C.ink2} />
                                    </TouchableOpacity>
                                </View>

                                <View style={s.filterField}>
                                    <Text style={s.filterLabel}>To Date</Text>
                                    <TouchableOpacity style={s.filterDateBtn} onPress={() => setFilterDateType('to')} activeOpacity={0.8}>
                                        <Icon name="calendar-today" size={17} color={C.primary} />
                                        <Text style={s.filterDateText}>{toDmy(toDate)}</Text>
                                        <Icon name="chevron-right" size={18} color={C.ink2} />
                                    </TouchableOpacity>
                                </View>
                            </View>
                            )}
                        </ScrollView>

                        <TouchableOpacity style={[s.btn, s.btnPrimary, { marginTop: 8 }]} onPress={() => {
                            setFilterOpen(false);
                        }}>
                            <Text style={s.btnPrimaryText}>{tab === 'beams' ? 'Apply Filters' : 'Done'}</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

            <ScannerModal
                visible={scannerOpen}
                onClose={() => setScannerOpen(false)}
                onScanned={raw => { setScannerOpen(false); loadScanned(raw); }}
            />

            <EditLineSheet
                visible={!!editLine}
                line={editLine}
                token={token} prpcode={activePrpCode} yearno={activeYearNo} stkType={stkType} dmy={dmy} expProdQtyType={expProdQtyType}
                beams={beams} beamsLoading={beamsLoading}
                onClose={() => setEditLine(null)}
                onSaved={msg => { setEditLine(null); showSuccess?.(msg); afterChange(); }}
            />
        </SafeAreaView>
    );
};

export default WeftCartonIssueScreen;
