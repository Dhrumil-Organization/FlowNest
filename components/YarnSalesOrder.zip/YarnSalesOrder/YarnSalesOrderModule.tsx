import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import YarnSalesOrder from './YarnSalesOrder';
import PartyListScreen from './PartyListScreen';
import OrderSummaryScreen from './OrderSummaryScreen';

import { SalesOrderProvider } from './SalesOrderContext';
import SalesOrderItemList from './SalesOrderItemList';
import SalesOrderGradeList from './SalesOrderGradeList';
import SalesOrderShadeList from './SalesOrderShadeList';
import SalesOrderDetails from './SalesOrderDetails';
import ItemAddedSuccessScreen from './ItemAddedSuccessScreen';
import SalesOrderAddAnotherShade from './SalesOrderAddAnotherShade';
import SalesOrderSaveSuccess from './SalesOrderSaveSuccess';
import PdfViewerScreen from './PdfViewerScreen';
import AddNewPartyScreen from './AddNewPartyScreen';
import AddNewItemScreen from './AddNewItemScreen';

const Stack = createNativeStackNavigator();

const YarnSalesOrderModule = props => {

    return (
        <SalesOrderProvider>

            <Stack.Navigator screenOptions={{ headerShown: false }}>

                <Stack.Screen name="SalesOrderBrowse">
                    {(screenProps) => (
                        <YarnSalesOrder
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>

                <Stack.Screen name="PartyListScreen">
                    {(screenProps) => (
                        <PartyListScreen
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>

                <Stack.Screen name="OrderSummaryScreen">
                    {(screenProps) => (
                        <OrderSummaryScreen
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="SalesOrderItemList">
                    {screenProps => (
                        <SalesOrderItemList
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="SalesOrderGradeList">
                    {screenProps => (
                        <SalesOrderGradeList
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="SalesOrderShadeList">
                    {screenProps => (
                        <SalesOrderShadeList
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="SalesOrderDetails">
                    {screenProps => (
                        <SalesOrderDetails
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="SalesOrderAddAnotherShade">
                    {screenProps => (
                        <SalesOrderAddAnotherShade
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>


                {/* <Stack.Screen name="ItemAddedSuccessScreen">
                    {screenProps => (
                        <ItemAddedSuccessScreen
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen> */}

                <Stack.Screen name="SalesOrderSaveSuccess">
                    {screenProps => (
                        <SalesOrderSaveSuccess
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="PdfViewerScreen">
                    {screenProps => (
                        <PdfViewerScreen
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="AddNewPartyScreen">
                    {screenProps => (
                        <AddNewPartyScreen
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
                <Stack.Screen name="AddNewItemScreen">
                    {screenProps => (
                        <AddNewItemScreen
                            {...screenProps}
                            token={props.token}
                            isConnected={props.isConnected}
                            username={props.username}
                        />
                    )}
                </Stack.Screen>
            </Stack.Navigator>
        </SalesOrderProvider>
    );
};

export default YarnSalesOrderModule;