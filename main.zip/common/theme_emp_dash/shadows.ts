export const Shadows = {
    card: {
      shadowColor: '#000',
  
      shadowOffset: {
        width: 0,
        height: 2,
      },
  
      shadowOpacity: 0.08,
  
      shadowRadius: 8,
  
      elevation: 3,
    },
  };