import Icon from '@expo/vector-icons/MaterialIcons';
import AsyncStorage from '@/common/utils/compatibleStorage';
import axios from "axios";
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import React, { useEffect, useRef, useState } from "react";
import { Animated, FlatList, Keyboard, Modal, RefreshControl, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { API } from "../../common/API/dynamicAPI";

const ShimmerBox = ({ width, height, radius = 12 }: any) => {
    const translateX = useRef(new Animated.Value(-250)).current;

    useEffect(() => {
        Animated.loop(
            Animated.timing(translateX, {
                toValue: 350,
                duration: 1400,
                useNativeDriver: true,
            }),
        ).start();
    }, []);

    return (
        <View
            style={{
                width,
                height,
                borderRadius: radius,
                backgroundColor: '#ECEFF3',
                overflow: 'hidden',
            }}
        >
            <Animated.View
                style={{
                    position: 'absolute',
                    width: 120,
                    height: '100%',
                    backgroundColor: 'rgba(255,255,255,0.55)',
                    transform: [{ translateX }],
                }}
            />
        </View>
    );
};

const PurchaseRateAuth = ({ navigation, token }) => {
    const router = useRouter();
    const [searchPurchaseTransport, setsearchPurchaseTransport] = useState("");
    const [PurchaseTransportData, setPurchaseTransportData] = useState([]);
    const [PurchaseTransportloading, setPurchaseTransportloading] = useState(false);
    const [activeTab, setActiveTab] = useState("request");
    const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);
    const [FormState, setFormState] = useState({
        values: {
            YearNo: '',
        }
    })
    const [alertData, setAlertData] = useState({
        visible: false,
        message: "",
        type: "warning",
    });
    const [remarks, setRemarks] = useState({});
    const [PurchaseTransportinitialLoaded, setPurchaseTransportinitialLoaded] = useState(false);
    const [ProductionDetails, setProductionDetails] = useState({});
    const [showPurchaseTransportInfo, setshowPurchaseTransportInfo] = useState({});
    const [PurchaseTransportDetails, setPurchaseTransportDetails] = useState([]);
    const [refreshing, setRefreshing] = useState(false);

    const showWarning = msg =>
        setAlertData({
            visible: true,
            message: msg,
            type: "warning",
        });

    const showSuccess = msg =>
        setAlertData({
            visible: true,
            message: msg,
            type: "success",
        });

    const showError = msg =>
        setAlertData({
            visible: true,
            message: msg,
            type: "error",
        });

    useEffect(() => {
        if(!token) return;
        if (!PurchaseTransportinitialLoaded) {
            fetchPurchaseTransportlist();
            setPurchaseTransportinitialLoaded(true);
        }
    }, [token]);

    useEffect(() => {
        if(!token) return;
        setshowPurchaseTransportInfo({});
        setProductionDetails({});
        if (PurchaseTransportinitialLoaded) {
            fetchPurchaseTransportlist();
        }
    }, [token, activeTab]);

    const onRefresh = async () => {
        setRefreshing(true);

        await fetchPurchaseTransportlist();

        setRefreshing(false);
    };

    const fetchPurchaseTransportlist = async () => {
        setPurchaseTransportloading(true);
        const userPtype = await AsyncStorage.getItem('user_prptype');

        let yno = await AsyncStorage.getItem('yno');
        console.log("userPtype : => ", userPtype)
        console.log("yno : => ", yno)
        let atype = 'B';
        if (activeTab === 'history') {
            atype = 'H';
        }
        try {
            const payload = {
                prpcode: 'MT',
                prptype: userPtype,
                strcode: '',
                yearno: yno,
                txntype: 'purchase_transport_auth',
                referrer: 'dashboard',
                atype: atype,
            };

            console.log("browse payload", payload);

            const res = await axios.get(`${API}/api/purchasebrowse`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                },
                params: payload,
            });
            console.log("browse res", res)
            console.log("rawData", res?.data?.response?.data)
            console.log("rawDataD1", res?.data?.response?.d1)

            const rawData = res?.data?.response?.data || [];
            const rawDataD1 = res?.data?.response?.d1 || [];

            setPurchaseTransportData(rawData);
            setPurchaseTransportDetails(rawDataD1);

            if (res?.data?.response?.error == true) {
                showWarning("Please Try Again !!!");
            }
        } catch (e) {
            console.log(e);
            setPurchaseTransportData([]);
        } finally {
            setPurchaseTransportloading(false);
        }
    };

    const filteredData = PurchaseTransportData.filter(item => {
        const search = searchPurchaseTransport.trim().toLowerCase();

        if (!search) return true;

        const itemDetails = PurchaseTransportDetails.filter(
            d => d.uid === item.uid
        );

        const headerValues = [
            item.inwno,
            item.inwdate,
            item.parcode,
            item.parname,
            item.mainstrname,
            item.invtype,
            item.authstatus,
            item.aremark,
            item.authby,
            item.authdate,
            item.countofitem,
        ];

        const headerMatch = headerValues.some(v =>
            String(v ?? "").toLowerCase().includes(search)
        );

        const detailMatch = itemDetails.some(detail => {
            const detailValues = [
                detail.srno,
                detail.itmname,
                detail.curr,
                detail.currrate,
                detail.exrate,
                detail.porate,
                detail.poamt,
                detail.potrpper,
                detail.potrpamt,
                detail.purrate,
                detail.puramt,
                detail.purtrpper,
                detail.purtrpamt,
                detail.amount,
            ];

            return detailValues.some(v =>
                String(v ?? "").toLowerCase().includes(search)
            );
        });

        return headerMatch || detailMatch;
    });

    console.log("PurchaseTransportData Length :", PurchaseTransportData?.length);
    console.log("filteredData Length :", filteredData?.length);
    console.log("searchPurchaseTransport :", searchPurchaseTransport);

    const getToken = () => {
        return token;
    };

    const fetchauthoriseddata = async (item, isauthValue, authData) => {
        setPurchaseTransportloading(true);
        const userPtype = await AsyncStorage.getItem('user_prptype');
        let yno = await AsyncStorage.getItem('yno');
        console.log("userPtype : => ", userPtype)
        console.log("yno : => ", yno)
        try {
            const params = {
                prptype: userPtype,
                yearno: yno,
                ...item,
                isauth: isauthValue,
                txntype: "purchase_transport_auth",
                remark: remarks[item?.uid] || "",
                action: 'edit',
                referrer: "dashboard",
                ARemark: remarks[item?.uid] || "",
                aremark: remarks[item?.uid] || "",
            };
            console.log("Purchase Rate Auth Auth Payload DATA=> ", params);

            const res = await axios.post(
                `${API}/api/authpurchase`,
                params,
                {
                    headers: {
                        Authorization: `Bearer ${getToken()}`,
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                    },
                }
            );
            console.log("Purchase Rate Auth Auth Response => ", res);

            if (res?.data?.response?.error == true) {
                showError("Please Try Again");
            } else if (res?.data?.success == true) {
                showSuccess(res?.data.response?.message);
                const rawData = res?.data?.response?.data || [];
                const rawDataD1 = res?.data?.response?.d1 || [];

                setPurchaseTransportData(rawData);
                setPurchaseTransportDetails(rawDataD1);
            }
        } catch (error) {
            console.log("Purchase Rate Auth Auth ERROR:", error?.response?.data || error.message);
            showError(
                error?.response?.data?.message ||
                error?.message ||
                "Failed."
            );
        } finally {

            setPurchaseTransportloading(false);
        }
    };

    // const renderSkeleton = () => {
    //     return [1, 2, 3, 4].map((item) => (
    //         <View key={item} style={styles.skeletonCard}>
    //             <View style={styles.skeletonHeader}>
    //                 <View style={styles.skeletonCircle} />
    //                 <View style={{ flex: 1 }}>
    //                     <View style={styles.skeletonLineLarge} />
    //                     <View style={styles.skeletonLineSmall} />
    //                 </View>
    //             </View>
    //             <View style={styles.skeletonMiddle} />
    //             <View style={styles.skeletonFooter} />
    //         </View>
    //     ));
    // };

    const renderSkeleton = () => {
        return [1, 2, 3, 4].map((item) => (
            <View key={item} style={styles.skeletonCard}>

                <View style={styles.skeletonHeader}>
                    <ShimmerBox
                        width={56}
                        height={56}
                        radius={18}
                    />

                    <View
                        style={{
                            flex: 1,
                            marginLeft: 14,
                        }}
                    >
                        <ShimmerBox
                            width={'80%'}
                            height={18}
                        />

                        <View style={{ height: 10 }} />

                        <ShimmerBox
                            width={'45%'}
                            height={14}
                        />
                    </View>
                </View>

                <View style={{ height: 20 }} />

                <ShimmerBox
                    width={'95%'}
                    height={14}
                />

                <View style={{ height: 12 }} />

                <ShimmerBox
                    width={'70%'}
                    height={14}
                />

                <View style={{ height: 20 }} />

                <View
                    style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                    }}
                >
                    <ShimmerBox
                        width={'45%'}
                        height={18}
                    />

                    <ShimmerBox
                        width={42}
                        height={42}
                        radius={12}
                    />
                </View>
            </View>
        ));
    };

    const goBack = () => {
        if (router.canGoBack()) router.back();
        else router.replace('/');
    };

    return (

        <View style={styles.container}>
            <LinearGradient colors={['#0B6477', '#14919B']} style={styles.header}>
                <TouchableOpacity onPress={goBack} style={styles.headerIconBtn} >
                    <Icon name="arrow-back-ios-new" size={20} color="#fff" />
                </TouchableOpacity>

                <Text style={styles.headerTitle}> Purchase Rate Auth </Text>

                <View style={{ width: 30 }} />
            </LinearGradient>

            <View style={styles.mainSearchBox}>
                <Icon name="search" size={20} color="#000" />
                <TextInput
                    placeholder="Search an Purchase..."
                    placeholderTextColor="#000"
                    value={searchPurchaseTransport}
                    onChangeText={setsearchPurchaseTransport}
                    style={styles.mainSearchInput}
                    returnKeyType="search"
                />

                {searchPurchaseTransport?.length > 0 && (
                    <TouchableOpacity onPress={() => { setsearchPurchaseTransport(""); Keyboard.dismiss(); }} style={styles.clearBtn}>
                        <Icon name="close" size={20} color="#666" />
                    </TouchableOpacity>
                )}
            </View>

            <View style={styles.tabContainer}>
                <TouchableOpacity
                    style={[
                        styles.tabBtn,
                        activeTab === "request" && styles.activeTab
                    ]}
                    onPress={() => setActiveTab("request")}
                >
                    <Text
                        style={[
                            styles.tabText,
                            activeTab === "request" && styles.activeTabText
                        ]}
                    >
                        Request
                    </Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[
                        styles.tabBtn,
                        activeTab === "history" && styles.activeTab
                    ]}
                    onPress={() => setActiveTab("history")}
                >
                    <Text
                        style={[
                            styles.tabText,
                            activeTab === "history" && styles.activeTabText
                        ]}
                    >
                        History
                    </Text>
                </TouchableOpacity>
            </View>

            {PurchaseTransportloading ? (
                <View style={{ paddingTop: 10 }}>
                    {renderSkeleton()}
                </View>
            ) : (
                <FlatList
                    data={filteredData}
                    nestedScrollEnabled={true}
                    keyboardShouldPersistTaps="handled"
                    keyExtractor={(item, index) => index.toString()}
                    refreshControl={
                        <RefreshControl
                            refreshing={refreshing}
                            onRefresh={onRefresh}
                            colors={["#14919B"]}
                            tintColor="#14919B"
                        />
                    }
                    contentContainerStyle={{
                        paddingBottom: 30,
                        paddingTop: 10,
                    }}
                    renderItem={({ item }) => {
                        return (
                            <View style={[
                                styles.proCard,
                                showPurchaseTransportInfo[item.uid] && {
                                    minHeight:
                                        activeTab === "history"
                                            ? 520
                                            : 560
                                },
                                item.authstatus?.toLowerCase() === "authorised" &&
                                styles.authorisedCard,
                                item.authstatus?.toLowerCase() === "rejected" &&
                                styles.rejectCard,
                            ]}>
                                {
                                    item.authstatus?.toLowerCase() !== "authorised" &&
                                    item.authstatus?.toLowerCase() !== "rejected" && (
                                        <View style={styles.leftAccent} />
                                    )
                                }
                                <View style={styles.cardTopNew}>
                                    <Text style={styles.topDate}>
                                        {item.inwno}
                                    </Text>

                                    <Text style={styles.topInward}>
                                        {item.inwdate}
                                    </Text>
                                </View>

                                <View style={styles.partyMainSection}>
                                    <View style={{ flex: 1 }}>
                                        <Text style={styles.partyCodeText}>
                                            {item.parcode}
                                        </Text>
                                        <Text numberOfLines={2} style={styles.partyNameText} >
                                            {item.parname}
                                        </Text>
                                    </View>

                                    <View
                                        style={[
                                            styles.statusBadgePro,
                                            item.authstatus?.toLowerCase() === "authorised"
                                                ? styles.authBadge
                                                : styles.pendingBadge
                                        ]}
                                    >
                                        <Text
                                            style={[
                                                styles.statusTextPro,
                                                item.authstatus?.toLowerCase() === "authorised"
                                                    ? styles.authText
                                                    : styles.pendingText
                                            ]}
                                        >
                                            {item.authstatus}
                                        </Text>
                                    </View>
                                </View>

                                {activeTab !== "history" && (
                                    <View
                                        style={{
                                            marginTop: 10,
                                            marginBottom: 10,
                                        }}
                                    >
                                        <Text style={styles.newLabel}>
                                            Str Name
                                        </Text>

                                        <Text
                                            style={{
                                                color: "#0F8F9A",
                                                fontSize: 13,
                                                fontWeight: "800",
                                            }}
                                        >
                                            {item.mainstrname || "-"}
                                        </Text>
                                    </View>
                                )}

                                <View style={styles.middleInfoRow}>
                                </View>

                                <View style={styles.poMainRow}>
                                    <View style={{ flex: 1 }}>

                                        {activeTab === "history" && (
                                            <>
                                                <Text style={[styles.newLabel, { marginTop: 12 }]}>
                                                    Str Name
                                                </Text>

                                                <Text style={{ color: "#0F8F9A", fontSize: 13, fontWeight: "800", }}>
                                                    {item.mainstrname || "-"}
                                                </Text>
                                            </>
                                        )}
                                    </View>

                                    {activeTab === "history" && (
                                        <TouchableOpacity
                                            style={styles.poInfoIconBtn}
                                            onPress={() =>
                                                setshowPurchaseTransportInfo(prev => ({
                                                    ...prev,
                                                    [item.uid]: !prev[item.uid]
                                                }))
                                            }
                                        >
                                            <Text style={styles.poInfoCountText}>
                                                {item.countofitem}
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                </View>

                                <View style={styles.remarkRowBox}>

                                    {activeTab !== "history" ? (
                                        <>
                                            <Text style={styles.remarkLeftLabel}>
                                                Remark
                                            </Text>

                                            <TextInput
                                                placeholder="Enter Remark"
                                                placeholderTextColor="#000"
                                                value={remarks[item?.uid] || ""}
                                                onChangeText={(text) => {
                                                    setRemarks(prev => ({
                                                        ...prev,
                                                        [item?.uid]: text
                                                    }))
                                                }}
                                                style={styles.remarkRightInput}
                                            />
                                        </>
                                    ) : (
                                        <View style={{ flex: 1 }} />
                                    )
                                    }

                                    {activeTab !== "history" && (
                                        <TouchableOpacity
                                            style={styles.poInfoIconBtn}
                                            onPress={() =>
                                                setshowPurchaseTransportInfo(prev => ({
                                                    ...prev,
                                                    [item.uid]: !prev[item.uid]
                                                }))
                                            }
                                        >
                                            <Text style={styles.poInfoCountText}>
                                                {item.countofitem}
                                            </Text>
                                        </TouchableOpacity>
                                    )}

                                </View>

                                {showPurchaseTransportInfo[item.uid] && (
                                    <View style={styles.poInfoBox}>
                                        <ScrollView nestedScrollEnabled style={styles.poScrollArea} showsVerticalScrollIndicator={false}>
                                            {PurchaseTransportDetails
                                                .filter(d => d.uid === item.uid)
                                                .map((detail, idx) => {

                                                    console.log("DETAIL =>", {
                                                        purrate: detail.purrate,
                                                        porate: detail.porate,
                                                        purtrpamt: detail.purtrpamt,
                                                        potrpamt: detail.potrpamt,
                                                    });

                                                    console.log(
                                                        "COMPARE =>",
                                                        Number(detail.purrate || 0),
                                                        ">",
                                                        Number(detail.porate || 0),
                                                        "=",
                                                        Number(detail.purrate || 0) > Number(detail.porate || 0),

                                                        " | ",

                                                        Number(detail.purtrpamt || 0),
                                                        ">",
                                                        Number(detail.potrpamt || 0),
                                                        "=",
                                                        Number(detail.purtrpamt || 0) > Number(detail.potrpamt || 0)
                                                    );

                                                    return (
                                                        <View
                                                            key={idx}
                                                            style={[
                                                                styles.itemDetailCard,
                                                                (
                                                                    (
                                                                        Number(Number(detail.porate || 0).toFixed(2)) > 0 &&
                                                                        Number(Number(detail.purrate || 0).toFixed(2)) > Number(Number(detail.porate || 0).toFixed(2))
                                                                    ) ||
                                                                    (
                                                                        Number(Number(detail.potrpamt || 0).toFixed(2)) > 0 &&
                                                                        Number(Number(detail.purtrpamt || 0).toFixed(2)) > Number(Number(detail.potrpamt || 0).toFixed(2))
                                                                    )
                                                                ) && {
                                                                    borderColor: "#EF4444",
                                                                    borderWidth: 2,
                                                                    backgroundColor: "#FEF2F2",
                                                                }
                                                            ]}
                                                        >

                                                            <View style={styles.itemHeader}>
                                                                <View style={{ flex: 1 }}>
                                                                    <Text style={styles.itemTitle}>
                                                                        {detail.itmname}
                                                                    </Text>
                                                                </View>

                                                                <View style={styles.srBadge}>
                                                                    <Text style={styles.srBadgeText}>
                                                                        #{detail.srno}
                                                                    </Text>
                                                                </View>
                                                            </View>

                                                            <Text style={styles.sectionTitle}>
                                                                Purchase Order
                                                            </Text>

                                                            <View style={styles.detailRow}>
                                                                {/* <View style={styles.detailBox}>
                                                                <Text style={styles.detailLabel}>PO Curr</Text>
                                                                <Text style={styles.detailValue}>{detail.curr || '-'}</Text>
                                                            </View> */}

                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>PO Trp Per.</Text>
                                                                    <Text style={styles.detailValue}>
                                                                        {Number(detail.potrpper).toFixed(2) || '-'}
                                                                    </Text>
                                                                </View>

                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>PO Trp Amount</Text>
                                                                    <Text style={styles.detailValue}>
                                                                        {Number(detail.potrpamt).toFixed(2) || '-'}
                                                                    </Text>
                                                                </View>
                                                            </View>

                                                            <View style={styles.detailRow}>
                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>PO Rate</Text>
                                                                    <Text style={styles.detailValue}>
                                                                        {Number(detail.porate).toFixed(2) || '-'}
                                                                    </Text>
                                                                </View>

                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>PO Amount</Text>
                                                                    <Text style={styles.amountValue}>{detail.poamt || '-'}</Text>
                                                                </View>
                                                            </View>

                                                            <View style={styles.cardDividerLine} />

                                                            <Text style={styles.sectionTitle}>
                                                                Purchase
                                                            </Text>

                                                            {/* Row 1 */}
                                                            <View style={styles.detailRow}>
                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>Pur Trp Per.</Text>
                                                                    <Text style={styles.detailValue}>
                                                                        {Number(detail.purtrpper || 0).toFixed(2)}
                                                                    </Text>
                                                                </View>

                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>Pur Trp Amount</Text>
                                                                    <Text style={styles.amountValue}>
                                                                        {Number(detail.purtrpamt || 0).toFixed(2)}
                                                                    </Text>
                                                                </View>
                                                            </View>

                                                            {/* Row 2 */}
                                                            <View style={styles.detailRow}>
                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>Pur Rate</Text>
                                                                    <Text style={styles.detailValue}>
                                                                        {Number(detail.purrate || 0).toFixed(2)}
                                                                    </Text>
                                                                </View>

                                                                <View style={styles.detailBox}>
                                                                    <Text style={styles.detailLabel}>Pur Amount</Text>
                                                                    <Text style={styles.amountValue}>
                                                                        {Number(detail.puramt || detail.amount || 0).toFixed(2)}
                                                                    </Text>
                                                                </View>
                                                            </View>
                                                        </View>
                                                    );
                                                })}
                                        </ScrollView>
                                    </View>
                                )}

                                {activeTab === "history" && (
                                    <>
                                        <View style={styles.proDivider} />

                                        <View style={styles.historyRemarkBox}>
                                            <Text style={styles.historyRemarkLabel}>
                                                Remark
                                            </Text>

                                            <Text style={styles.historyRemarkText}>
                                                {item.aremark || "-"}
                                            </Text>
                                        </View>

                                        <View style={styles.authFooterRow}>

                                            <View style={styles.authFooterBoxLeft}>
                                                <Text style={styles.authFooterLabel}>
                                                    Auth By
                                                </Text>

                                                <Text style={styles.authFooterValue}>
                                                    {item.authby || "-"}
                                                </Text>
                                            </View>

                                            <View style={styles.authFooterBoxRight}>
                                                <Text style={styles.authFooterLabel}>
                                                    Auth Date
                                                </Text>

                                                <Text style={styles.authFooterValue}>
                                                    {item.authdate || "-"}
                                                </Text>
                                            </View>
                                        </View>
                                    </>
                                )}

                                {activeTab !== "history" && (
                                    <>
                                        <View style={styles.proDivider} />

                                        <View style={styles.buttonRowPro}>
                                            <TouchableOpacity
                                                style={styles.rejectIconBtn}
                                                onPress={() => fetchauthoriseddata(item, 2)}
                                            >
                                                <Icon name="close" size={22} color="#DC2626" />
                                            </TouchableOpacity>

                                            <TouchableOpacity
                                                style={styles.approveIconBtn}
                                                onPress={() => {
                                                    if (!(remarks[item?.uid] || "").trim()) {
                                                        showWarning("Please enter remark before approval.");
                                                        return;
                                                    }

                                                    fetchauthoriseddata(item, 1);
                                                }}
                                            >
                                                <Icon name="check" size={22} color="#16A34A" />
                                            </TouchableOpacity>
                                        </View>
                                    </>
                                )}
                            </View>
                        );
                    }}

                    ListEmptyComponent={
                        < View style={styles.emptyContainer} >

                            <View style={styles.emptyIconBox}>
                                <Icon name="inventory-2" size={60} color="#AAB7C4" />
                            </View>

                            <Text style={styles.emptyTitle}>
                                No Purchase Rate Auth Data
                            </Text>

                            <Text style={styles.emptySubtitle}>
                                Purchase Rate Auth records will appear here
                            </Text>
                        </View >
                    }
                />
            )}

            <Modal transparent visible={alertData.visible} animationType="fade">
                <View style={styles.alertOverlay}>
                    <View style={styles.alertBox}>
                        <Icon
                            name={
                                alertData.type === "success"
                                    ? "check-circle"
                                    : alertData.type === "error"
                                        ? "error"
                                        : "warning"
                            }
                            size={42}
                            color={
                                alertData.type === "success"
                                    ? "#4CAF50"
                                    : alertData.type === "error"
                                        ? "#F44336"
                                        : "#FFA000"
                            }
                        />

                        <Text style={styles.alertTitle}>
                            {
                                alertData.type === "success"
                                    ? "Success"
                                    : alertData.type === "error"
                                        ? "Error"
                                        : "Warning"
                            }
                        </Text>

                        <Text style={styles.alertMessage}>
                            {alertData.message}
                        </Text>

                        <TouchableOpacity
                            onPress={() =>
                                setAlertData({
                                    visible: false,
                                    message: "",
                                    type: "warning"
                                })
                            }
                            style={styles.alertBtn}
                        >
                            <Text style={{ color: "#fff", fontWeight: "700" }}>
                                OK
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>
        </View >
    );
};

export default PurchaseRateAuth;

const styles = StyleSheet.create({

    container: { flex: 1, backgroundColor: "#F4F6FA", },
    header: {
        paddingTop: 20, paddingBottom: 28, paddingHorizontal: 22, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomLeftRadius: 34, borderBottomRightRadius: 34,
        elevation: 12, shadowColor: "#000", shadowOpacity: 0.18, shadowRadius: 12,
    },
    headerTitle: { color: "#fff", fontSize: 20, fontWeight: "800", letterSpacing: 0.5, },
    headerIconBtn: { width: 50, height: 50, borderRadius: 18, backgroundColor: "rgba(255,255,255,0.14)", justifyContent: "center", alignItems: "center", borderWidth: 1, borderColor: "rgba(255,255,255,0.08)", },
    mainSearchBox: {
        flexDirection: "row", alignItems: "center", backgroundColor: "#fff", marginHorizontal: 20, marginTop: -20, borderRadius: 22, paddingHorizontal: 18, height: 50, elevation: 10, shadowColor: "#000",
        shadowOpacity: 0.12, shadowRadius: 12,
    },
    mainSearchInput: {
        flex: 1,
        marginLeft: 14,
        color: "#111",
        fontSize: 16,
        fontWeight: "500",
        paddingRight: 10,
    },
    tabContainer: { flexDirection: "row", marginHorizontal: 18, marginTop: 18, backgroundColor: "#EAF2F4", borderRadius: 20, padding: 5, alignSelf: "center", width: "92%", },
    tabBtn: { flex: 1, paddingVertical: 15, borderRadius: 16, alignItems: "center", justifyContent: "center", },
    activeTab: { backgroundColor: "#127C85", elevation: 6, shadowColor: "#14919B", shadowOpacity: 0.35, shadowRadius: 10, },
    tabText: { color: "#344054", fontWeight: "700", fontSize: 14, },
    activeTabText: { color: "#fff", },
    infoBox: { flex: 1, },
    merchantName: { marginTop: 2, fontSize: 12, color: "#6B7280", fontWeight: "500", },
    bottomRow: { marginTop: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "center", },
    bottomLabel: { color: "#64748B", fontSize: 11, fontWeight: "700", marginBottom: 2, },
    amountSection: { flex: 1, },
    storeSection: { alignItems: "flex-end", },
    qtyText: { color: "#DC2626", fontSize: 18, fontWeight: "800", },
    amountText: { color: "#DC2626", fontSize: 16, fontWeight: "800", },
    billText: { marginTop: 6, fontSize: 13, color: "#64748B", fontWeight: "700", },
    dateText: { color: "#000", fontSize: 13, fontWeight: "500", },
    billBadge: { backgroundColor: "#F3F4F6", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, },
    billBadgeText: { color: "#000", fontSize: 12, fontWeight: "600", },
    statusBadge: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 30, justifyContent: "center", alignItems: "center", backgroundColor: "#FFF7ED", borderWidth: 1, borderColor: "#FED7AA", },
    merchantBox: { marginTop: 18, flexDirection: "row", alignItems: "center", backgroundColor: "#F8FAFC", paddingHorizontal: 14, paddingVertical: 12, borderRadius: 18, },
    merText: { marginLeft: 8, color: "#334155", fontSize: 13, fontWeight: "700", flex: 1, },
    cardDivider: { height: 1, backgroundColor: "#EEF2F7", marginTop: 18, },
    purchaseBottom: { marginTop: 18, flexDirection: "row", justifyContent: "space-between", alignItems: "center", },
    balanceText: { color: "#2563EB", fontSize: 14, fontWeight: "800", },
    storeBox: { flexDirection: "row", alignItems: "center", paddingHorizontal: 15, paddingVertical: 10, borderRadius: 18, backgroundColor: "#ECFEFF", borderWidth: 1, borderColor: "#CFFAFE", },
    purchaseTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", },
    emptyText: { textAlign: "center", color: "#000", fontSize: 16, },
    overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.35)", justifyContent: "flex-end", },
    sheet: { backgroundColor: "#fff", borderTopLeftRadius: 34, borderTopRightRadius: 34, padding: 24, maxHeight: "90%", elevation: 20, },
    modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", },
    modalTitle: { fontSize: 20, fontWeight: "700", color: "#000", },
    label: { marginTop: 18, marginBottom: 8, fontWeight: "700", color: "#000", },
    filterSearchBox: { flexDirection: "row", alignItems: "center", backgroundColor: "#F4F6F8", borderRadius: 12, paddingHorizontal: 12, height: 48, },
    filterInput: { flex: 1, marginLeft: 8, color: "#000", },
    selectItem: { flexDirection: "row", alignItems: "center", paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: "#eee", },
    loadBtn: {
        backgroundColor: "#14919B", height: 62, borderRadius: 20, marginTop: 28, justifyContent: "center", alignItems: "center", flexDirection: "row", elevation: 8,
        shadowColor: "#14919B", shadowOpacity: 0.35, shadowRadius: 12,
    },
    loadText: { color: "#fff", fontWeight: "700", marginLeft: 8, },
    selectBox: {
        height: 60, backgroundColor: "#F8FAFB", borderRadius: 18, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between",
        borderWidth: 1, borderColor: "#E5E7EB",
    },
    selectText: { color: "#000", flex: 1, fontSize: 15, },
    dropdownBox: { backgroundColor: "#fff", borderRadius: 14, marginTop: 10, padding: 10, elevation: 5, },
    emptyContainer: { marginTop: 120, alignItems: "center", },
    emptyIconBox: { width: 120, height: 120, borderRadius: 60, backgroundColor: "#EDF3F5", justifyContent: "center", alignItems: "center", },
    emptyTitle: { marginTop: 24, fontSize: 18, fontWeight: "800", color: "#111827", },
    emptySubtitle: { marginTop: 8, fontSize: 15, color: "#000", },
    skeletonCard: { backgroundColor: "#fff", marginHorizontal: 16, marginTop: 14, borderRadius: 20, padding: 16, elevation: 4, },
    skeletonHeader: { flexDirection: "row", alignItems: "center", },
    skeletonCircle: { width: 56, height: 56, borderRadius: 18, backgroundColor: "#E5E7EB", marginRight: 14, },
    skeletonLineLarge: { height: 18, width: "80%", borderRadius: 8, backgroundColor: "#E5E7EB", },
    skeletonLineSmall: { height: 14, width: "50%", borderRadius: 8, backgroundColor: "#E5E7EB", marginTop: 10, },
    skeletonMiddle: { height: 14, width: "90%", borderRadius: 8, backgroundColor: "#E5E7EB", marginTop: 22, },
    skeletonFooter: { height: 18, width: "40%", borderRadius: 8, backgroundColor: "#E5E7EB", marginTop: 22, },
    infoRow: { flexDirection: "row", alignItems: "center", marginBottom: 4, },
    doubleRow: { flexDirection: "row", marginTop: 14, },
    doubleItem: { flex: 1, marginRight: 10, },
    infoLabel: { color: "#000", fontSize: 14, fontWeight: "700", marginBottom: 3, },
    infoValue: { color: "#111827", fontSize: 13, fontWeight: "600", },
    bottomMainRow: { marginTop: 16, flexDirection: "row", justifyContent: "space-between", alignItems: "center", },
    actionContainer: { flexDirection: "row", alignItems: "center", },
    topSectionNew: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    cardDividerNew: {
        height: 1,
        backgroundColor: "#EEF2F6",
        marginTop: 10,
    },
    itemTitleNew: {
        fontSize: 17,
        fontWeight: "800",
        color: "#111827",
    },
    mergeTitleNew: {
        marginTop: 4,
        fontSize: 13,
        color: "#667085",
        fontWeight: "600",
    },
    infoGrid: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    infoRowNew: {
        flexDirection: "row",
        alignItems: "center",
        flex: 1,
    },
    infoLabelNew: {
        color: "#94A3B8",
        fontSize: 12,
        fontWeight: "700",
        marginRight: 4,
    },
    infoValueNew: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "700",
    },
    qtyValueNew: {
        color: "#111827",
        fontSize: 14,
        fontWeight: "900",
    },
    storeValueNew: {
        color: "#155EEF",
        fontSize: 14,
        fontWeight: "800",
    },
    bottomActionsNew: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 16,
    },
    rejectBtnNew: {
        flex: 1,
        height: 48,
        borderRadius: 14,
        backgroundColor: "#FFF1F2",
        borderWidth: 1,
        borderColor: "#FECACA",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        marginRight: 8,
    },
    approveBtnNew: {
        flex: 1,
        height: 48,
        borderRadius: 14,
        backgroundColor: "#ECFDF3",
        borderWidth: 1,
        borderColor: "#BBF7D0",
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        marginLeft: 8,
    },
    rejectTextNew: {
        color: "#DC2626",
        fontSize: 14,
        fontWeight: "700",
        marginLeft: 6,
    },
    approveTextNew: {
        color: "#16A34A",
        fontSize: 14,
        fontWeight: "700",
        marginLeft: 6,
    },
    proCard: {
        backgroundColor: "#FFFFFF",
        marginHorizontal: 14,
        marginTop: 12,
        borderRadius: 22,
        paddingHorizontal: 16,
        paddingVertical: 16,
        borderWidth: 1,
        borderColor: "#E9EEF5",
        elevation: 4,
        shadowColor: "#000",
        shadowOpacity: 0.06,
        shadowRadius: 8,
        shadowOffset: {
            width: 0,
            height: 3,
        },
        overflow: "hidden",
    },
    leftAccent: {
        position: "absolute",
        left: 0,
        top: 0,
        bottom: 0,
        width: 3,
        backgroundColor: "#14919B",
    },
    cardTopNew: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        backgroundColor: "#F8FAFC",
        marginHorizontal: -16,
        marginTop: -16,
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderTopLeftRadius: 22,
        borderTopRightRadius: 22,
    },
    topDate: {
        color: "#111827",
        fontSize: 14,
        fontWeight: "700",
    },
    topInward: {
        color: "#111827",
        fontSize: 14,
        fontWeight: "800",
    },
    mainItemName: {
        fontSize: 14,
        fontWeight: "800",
        color: "#111827",
        letterSpacing: 0.3,
    },
    subMerge: {
        marginTop: 5,
        color: "#000",
        fontSize: 13,
        fontWeight: "600",
    },
    proDivider: {
        height: 1,
        backgroundColor: "#EEF2F6",
        marginTop: 14,
        marginBottom: 10,
    },
    infoMainSection: {
        marginTop: 12,
    },
    infoSingleRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 10,
    },
    leftLabel: {
        color: "#000",
        fontSize: 13,
        fontWeight: "700",
    },
    rightValue: {
        color: "#111827",
        fontSize: 14,
        fontWeight: "700",
    },
    qtyProText: {
        color: "#111827",
        fontSize: 15,
        fontWeight: "900",
    },
    storeProText: {
        color: "#155EEF",
        fontSize: 15,
        fontWeight: "800",
    },
    buttonRowPro: {
        flexDirection: "row",
        justifyContent: "flex-end",
        alignItems: "center",
    },
    rejectIconBtn: {
        width: 42,
        height: 42,
        borderRadius: 12,
        backgroundColor: "#FEF2F2",
        borderWidth: 1,
        borderColor: "#cc3434",
        justifyContent: "center",
        alignItems: "center",
        marginRight: 10,
    },
    approveIconBtn: {
        width: 42,
        height: 42,
        borderRadius: 12,
        backgroundColor: "#ECFDF3",
        borderWidth: 1,
        borderColor: "#24c25b",
        justifyContent: "center",
        alignItems: "center",
    },
    itemStatusRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "flex-start",
        marginTop: 14,
    },
    statusBadgePro: {
        backgroundColor: "#FEF3C7",
        borderWidth: 1,
        borderColor: "#FCD34D",
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 30,
        marginLeft: 10,
    },
    statusTextPro: {
        color: "#B45309",
        fontSize: 11,
        fontWeight: "800",
    },
    rejectProText: {
        color: "#DC2626",
        fontSize: 14,
        fontWeight: "700",
        marginLeft: 5,
    },
    approveProText: {
        color: "#16A34A",
        fontSize: 14,
        fontWeight: "700",
        marginLeft: 5,
    },
    newCard: {
        backgroundColor: "#fff",
        marginHorizontal: 12,
        marginTop: 10,
        borderRadius: 18,
        paddingHorizontal: 14,
        paddingVertical: 12,
        borderWidth: 1,
        borderColor: "#EEF1F5",
        elevation: 2,
        shadowColor: "#000",
        shadowOpacity: 0.05,
        shadowRadius: 6,
        shadowOffset: {
            width: 0,
            height: 2,
        },
    },
    topRowNew: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    dateTextNew: {
        color: "#667085",
        fontSize: 12,
        fontWeight: "600",
    },
    inwardTextNew: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "800",
    },
    middleSection: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 14,
    },
    // detailBox: {
    //     flex: 1,
    //     marginRight: 6,
    // },
    // detailLabel: {
    //     color: "#98A2B3",
    //     fontSize: 10,
    //     marginBottom: 4,
    //     fontWeight: "700",
    // },
    // detailValue: {
    //     color: "#111827",
    //     fontSize: 12,
    //     fontWeight: "700",
    // },
    bottomMainSection: {
        marginTop: 16,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
    },
    bottomTitle: {
        color: "#98A2B3",
        fontSize: 10,
        marginBottom: 4,
        fontWeight: "700",
    },
    qtyTextNew: {
        color: "#111827",
        fontSize: 15,
        fontWeight: "900",
    },
    storeTextNew: {
        color: "#155EEF",
        fontSize: 14,
        fontWeight: "800",
    },
    actionBtns: {
        flexDirection: "row",
        alignItems: "center",
    },
    rejectCircle: {
        width: 38,
        height: 38,
        borderRadius: 19,
        borderWidth: 2,
        borderColor: "#FF3B30",
        justifyContent: "center",
        alignItems: "center",
        marginRight: 10,
    },
    approveCircle: {
        width: 38,
        height: 38,
        borderRadius: 19,
        borderWidth: 2,
        borderColor: "#16A34A",
        justifyContent: "center",
        alignItems: "center",
    },
    topMainRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "flex-start",
    },
    leftTopRow: {
        flexDirection: "row",
        alignItems: "center",
    },
    logoBox: {
        width: 54,
        height: 34,
        justifyContent: "center",
    },
    logoText: {
        fontSize: 22,
        fontWeight: "900",
        color: "#155EEF",
    },
    cardNumber: {
        color: "#111827",
        fontSize: 18,
        fontWeight: "700",
    },
    corporateBadge: {
        backgroundColor: "#EEF2FF",
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 8,
        marginTop: 6,
        alignSelf: "flex-start",
    },
    corporateText: {
        color: "#5B5BD6",
        fontSize: 12,
        fontWeight: "700",
    },
    rightTopSection: {
        alignItems: "flex-end",
    },
    reqNo: {
        color: "#667085",
        fontSize: 13,
        fontWeight: "700",
    },
    dateTime: {
        color: "#667085",
        fontSize: 11,
        marginTop: 2,
        fontWeight: "500",
    },
    userName: {
        fontSize: 20,
        fontWeight: "800",
        color: "#111827",
    },
    companyName: {
        fontSize: 13,
        color: "#667085",
        marginTop: 1,
        fontWeight: "500",
    },
    centerRow: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: 14,
    },
    categoryBadge: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "#F3F0FF",
        paddingHorizontal: 10,
        paddingVertical: 6,
        borderRadius: 8,
        alignSelf: "flex-start",
    },
    categoryText: {
        marginLeft: 4,
        color: "#5B5BD6",
        fontSize: 12,
        fontWeight: "700",
    },
    amountSectionNew: {
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderColor: "#E5E7EB",

        paddingHorizontal: 14,
        marginHorizontal: 10,
    },
    amountLabel: {
        color: "#667085",
        fontSize: 11,
        marginBottom: 2,
    },
    // amountValue: {
    //     fontSize: 16,
    //     fontWeight: "900",
    //     color: "#111827",
    // },
    bottomRowNew: {
        marginTop: 14,
        flexDirection: "row",
        justifyContent: "space-between",
    },
    bottomLabelNew: {
        color: "#98A2B3",
        fontSize: 11,
        marginBottom: 2,
        fontWeight: "700",
    },
    bottomValueNew: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "700",
    },
    bottomValueBlue: {
        color: "#155EEF",
        fontSize: 13,
        fontWeight: "800",
    },
    alertOverlay: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "rgba(0,0,0,0.4)",
    },

    alertBox: {
        width: "85%",
        backgroundColor: "#fff",
        borderRadius: 18,
        padding: 22,
        alignItems: "center",
    },

    alertTitle: {
        fontSize: 18,
        fontWeight: "700",
        marginTop: 10,
        color: "#000",
    },

    alertMessage: {
        textAlign: "center",
        marginTop: 10,
        color: "#444",
        fontSize: 14,
    },

    alertBtn: {
        marginTop: 18,
        backgroundColor: "#13879A",
        paddingHorizontal: 28,
        paddingVertical: 11,
        borderRadius: 10,
    },
    clearBtn: {
        width: 28,
        height: 28,
        borderRadius: 14,
        justifyContent: "center",
        alignItems: "center",
    },
    partyMainSection: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "flex-start",
        marginTop: 14,
    },

    partyCodeText: {
        fontSize: 15,
        fontWeight: "800",
        color: "#111827",
    },

    partyNameText: {
        marginTop: 4,
        fontSize: 13,
        color: "#111827",
        fontWeight: "600",
        paddingRight: 10,
    },
    authBadge: {
        backgroundColor: "#ECFDF3",
        borderColor: "#22C55E",
    },

    pendingBadge: {
        backgroundColor: "#FEF3C7",
        borderColor: "#FCD34D",
    },

    authText: {
        color: "#15803D",
    },

    pendingText: {
        color: "#B45309",
    },
    authorisedCard: {
        borderColor: "#22C55E",
        borderWidth: 3,
    },

    rejectCard: {
        borderColor: "#EF4444",
        borderWidth: 3,
    },
    authFooterRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 4,
    },

    authFooterBoxLeft: {
        flex: 1,
        alignItems: "flex-start",
    },

    authFooterBoxCenter: {
        flex: 1,
        alignItems: "center",
    },

    authFooterBoxRight: {
        flex: 1,
        alignItems: "flex-end",
    },

    authFooterBox: {
        flex: 1,
    },

    authFooterLabel: {
        color: "#111827",
        fontSize: 11,
        fontWeight: "700",
        marginBottom: 4,
    },

    authFooterValue: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "800",
    },
    remarkMainBox: {
        marginTop: 4,
        marginBottom: 8,
    },

    remarkLabel: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "700",
        marginBottom: 8,
    },

    remarkInput: {
        minHeight: 45,
        borderWidth: 1,
        borderColor: "#D0D5DD",
        borderRadius: 12,
        paddingHorizontal: 12,
        paddingVertical: 10,
        backgroundColor: "#fff",
        color: "#111827",
        fontSize: 13,
    },
    historyRemarkBox: {
        backgroundColor: "#F8FAFC",
        borderRadius: 12,
        paddingHorizontal: 12,
        paddingVertical: 10,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: "#627fa5",
    },

    historyRemarkLabel: {
        fontSize: 11,
        fontWeight: "700",
        color: "#000",
        marginBottom: 4,
    },

    historyRemarkText: {
        fontSize: 13,
        fontWeight: "600",
        color: "#111827",
        lineHeight: 18,
    },


    remarkLeftLabel: {
        width: 70,
        color: "#111827",
        fontSize: 13,
        fontWeight: "700",
    },


    topInfoRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 14,
    },

    topInfoBox: {
        width: "48%",
    },

    middleInfoRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 0,
        // marginTop: 8,
    },

    middleInfoBox: {
        flex: 1,
    },

    cartNoValue: {
        color: "#7C3AED",
        fontSize: 14,
        fontWeight: "800",
    },

    bottomQtyRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 14,
        marginTop: 4,
    },

    bottomQtyBox: {
        flex: 1,
        alignItems: "flex-start",
    },

    bottomQtyBoxCenter: {
        flex: 1,
        alignItems: "center",
    },

    bottomQtyBoxRight: {
        flex: 1,
        alignItems: "flex-end",
    },

    newLabel: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "700",
        marginBottom: 4,
    },

    newValue: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "800",
    },

    qtyNewValue: {
        color: "#111827",
        fontSize: 14,
        fontWeight: "900",
    },

    storeNewValue: {
        color: "#155EEF",
        fontSize: 14,
        fontWeight: "800",
    },
    infoIconBtn: {
        width: 42,
        height: 42,
        borderRadius: 12,
        backgroundColor: "#EFF6FF",
        borderWidth: 1,
        borderColor: "#BFDBFE",
        justifyContent: "center",
        alignItems: "center",
        marginRight: "auto",
    },

    poInfoBox: {
        backgroundColor: "#F8FAFC",
        borderRadius: 14,
        padding: 12,
        marginBottom: 14,
        borderWidth: 1,
        borderColor: "#E2E8F0",

        overflow: "visible",
    },

    poInfoRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 10,
        paddingBottom: 8,
        borderBottomWidth: 0.5,
        borderBottomColor: "#E5E7EB",
    },

    poInfoLabel: {
        color: "#111827",
        fontSize: 12,
        fontWeight: "700",
    },

    poInfoValue: {
        color: "#111827",
        fontSize: 13,
        fontWeight: "800",
    },

    poMainRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 18,
    },

    mergeMainCard: {
        backgroundColor: "#F8FBFD",

        borderRadius: 22,

        padding: 16,

        marginBottom: 16,

        borderWidth: 1,
        borderColor: "#E4EDF2",
    },

    mergeRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 14,
        // marginBottom: 14,
    },

    mergeLeft: {
        width: "48%",
        marginRight: 8,
    },

    // mergeRight: {
    //     width: "48%",
    //     alignItems: "flex-end",
    // },

    mergeLabel: {
        fontSize: 13,
        fontWeight: "700",
        color: "#111827",

        marginBottom: 6,

        // textTransform: "uppercase",
        letterSpacing: 0.5,
    },

    mergeValue: {
        fontSize: 14,
        fontWeight: "800",
        color: "#111827",
    },

    mergeDivider: {
        height: 1,
        backgroundColor: "#E5E7EB",

        marginVertical: 14,
    },

    poHeaderRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 10,
    },

    poHeaderText: {
        color: "#000",
        fontSize: 12,
        fontWeight: "800",
    },
    poScrollArea: {
        maxHeight: 175,
        minHeight: 175,
        paddingRight: 4,
    },
    createdMainRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        // marginTop: 14,
        marginBottom: 4,
    },

    createdLeftSection: {
        flex: 1,
    },

    createdRightSection: {
        width: 120,
        alignItems: "flex-end",
    },

    createdLabel: {
        fontSize: 13,
        fontWeight: "700",
        color: "#111827",
        marginBottom: 3,
    },

    createdValue: {
        fontSize: 14,
        fontWeight: "800",
        color: "#111827",
    },

    remarkRowBox: {
        flexDirection: "row",
        alignItems: "center",
        // marginTop: 8,
        marginBottom: 8,
    },

    remarkRightInput: {
        flex: 1,
        height: 42,
        borderWidth: 1,
        borderColor: "#000",
        borderRadius: 10,
        paddingHorizontal: 12,
        backgroundColor: "#fff",
        marginRight: 8,
    },


    // itemDetailCard: {
    //     backgroundColor: "#FFFFFF",
    //     borderRadius: 14,
    //     padding: 12,
    //     marginBottom: 10,
    //     borderWidth: 1,
    //     borderColor: "#E2E8F0",
    //     minHeight: 110,
    // },

    itemHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 10,
    },

    // itemTitle: {
    //     flex: 1,
    //     color: "#111827",
    //     fontSize: 14,
    //     fontWeight: "800",
    // },

    srBadge: {
        backgroundColor: "#E0F2FE",
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 20,
    },

    srBadgeText: {
        color: "#0369A1",
        fontWeight: "700",
        fontSize: 11,
    },

    detailGrid: {
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between",
    },

    detailCell: {
        width: "48%",
        marginBottom: 10,
    },

    // detailLabel: {
    //     color: "#000",
    //     fontSize: 11,
    //     fontWeight: "600",
    // },

    // detailValue: {
    //     color: "#111827",
    //     fontSize: 13,
    //     fontWeight: "700",
    // },

    // amountValue: {
    //     color: "#16A34A",
    //     fontSize: 14,
    //     fontWeight: "800",
    // },

    poInfoIconBtn: {
        width: 42,
        height: 42,
        borderRadius: 15, // perfect circle
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#EFF6FF",
        borderWidth: 1,
        borderColor: "#BFDBFE",
    },

    poInfoCountText: {
        color: "#2563EB",
        fontSize: 16,
        fontWeight: "900",
    },

    topRateRow: {
        flexDirection: "row",
        marginTop: 8,
    },

    topRateCell: {
        width: "33.33%",
    },

    bottomDetailRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 8,
    },

    bottomDetailCell: {
        flex: 1,
    },

    storeName: {
        color: '#0F8F9A',
        fontSize: 14,
        fontWeight: '800',
        textTransform: 'uppercase',
    },

    partyLabel: {
        fontSize: 12,
        color: '#000',
        fontWeight: '700',
        marginTop: 8,
    },

    partyName: {
        fontSize: 12,
        color: '#000',
        fontWeight: '800',
        marginTop: 2,
    },
    // detailRow: {
    //     flexDirection: "row",
    //     justifyContent: "space-between",
    //     marginTop: 12,
    // },

    // detailBox: {
    //     flex: 1,
    // },

    itemDetailCard: {
        backgroundColor: "#FFFFFF",
        borderRadius: 16,
        padding: 14,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: "#f8f8f8",
    },

    itemTitle: {
        flex: 1,
        color: "#111827",
        fontSize: 14,
        fontWeight: "800",
    },

    // detailLabel: {
    //     color: "#000",
    //     fontSize: 12,
    //     fontWeight: "600",
    //     marginBottom: 4,
    // },

    // detailValue: {
    //     color: "#000",
    //     fontSize: 12,
    //     fontWeight: "700",
    // },

    // amountValue: {
    //     color: "#16A34A",
    //     fontSize: 12,
    //     fontWeight: "800",
    // },

    sectionTitle: {
        fontSize: 13,
        fontWeight: '800',
        color: '#0F8F9A',
        marginTop: 8,
        marginBottom: 8,
        textTransform: 'uppercase',
    },

    cardDividerLine: {
        height: 1,
        backgroundColor: '#E5E7EB',
        marginVertical: 12,
    },

    detailRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 8,
    },

    detailBox: {
        flex: 1,
    },

    detailLabel: {
        color: '#000',
        fontSize: 11,
        fontWeight: '600',
        marginBottom: 4,
    },

    detailValue: {
        color: '#111827',
        fontSize: 13,
        fontWeight: '700',
    },

    amountValue: {
        color: '#000',
        fontSize: 13,
        fontWeight: '800',
    },
});