import { registerUiNodes } from '../uiRegistry';

// NEW: Beam Close — migrated from the old BeamClose/index.tsx +
// BeamClose/SelectBeam.tsx screens. permission path matches
// registry/modules/creel.permission.ts's new 'beam_close' resource.
registerUiNodes([
  {
    id: 'nav.beam_close',
    kind: 'navigation',
    title: 'Beam Close',
    permission: 'beam_close',
    action: 'view',
    route: 'beam-close',
    icon: 'layers',
    order: 70,
  },
]);
