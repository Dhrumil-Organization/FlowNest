import { registerPermissionArea } from '../permissionRegistry';

registerPermissionArea({
  key: 'production',
  name: 'Production',
  icon: 'construct-outline',
  displayOrder: 30,
  resources: [
    {
      key: 'creel',
      name: 'Creel Management',
      type: 'screen',
      displayOrder: 10,
      actions: [{ key: 'view', name: 'View' }, { key: 'add', name: 'Add' }, { key: 'edit', name: 'Edit' }, { key: 'delete', name: 'Delete', dangerous: true }],
      children: [
        { key: 'browser', name: 'Creel Browser', type: 'section', displayOrder: 10, actions: [{ key: 'view', name: 'View List' }, { key: 'filter', name: 'Filter' }, { key: 'search', name: 'Search' }] },
        { key: 'entry', name: 'Creel Entry', type: 'dialog', displayOrder: 20, actions: [{ key: 'add', name: 'Add' }, { key: 'edit', name: 'Edit' }, { key: 'save', name: 'Save' }] },
        { key: 'scanner', name: 'Carton Scanner', type: 'dialog', displayOrder: 30, actions: [{ key: 'scan', name: 'Scan Carton' }, { key: 'manual_search', name: 'Manual Search' }, { key: 'delete_carton', name: 'Delete Carton', dangerous: true }] },
      ],
    },
    // NEW: Checking Scanner — migrated from the old CheckingScanner/CheckingScannerNew
    // screens. Registered under the same 'production' area as Creel since it's the
    // same kind of floor-level scan-and-record workflow.
    {
      key: 'checking_scanner',
      name: 'Checking Scanner',
      type: 'screen',
      displayOrder: 40,
      actions: [
        { key: 'view', name: 'View' },
        { key: 'scan', name: 'Scan QR' },
        { key: 'manual_entry', name: 'Manual Entry' },
        { key: 'print', name: 'Print Sticker' },
        { key: 'delete', name: 'Delete Record', dangerous: true },
      ],
      children: [
        { key: 'list', name: 'Scanner List', type: 'dialog', displayOrder: 10, actions: [{ key: 'view', name: 'View List' }, { key: 'search', name: 'Search' }] },
      ],
    },
    // NOTE: 'beam_close' used to be registered here too, but it's now
    // owned by registry/modules/beam.permission.ts (which also adds the
    // newer 'beam_gaiting' resource) — having it in both files was a
    // genuine duplicate-registration conflict under the same 'production'
    // area. Removed here; see beam.permission.ts for the real definition.
  ],
});
