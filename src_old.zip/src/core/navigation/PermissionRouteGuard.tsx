import React from 'react';
import { Redirect } from 'expo-router';
import { ActivityIndicator, View } from 'react-native';
import { useAppSessionStore } from '../../stores/AppSessionStore';
import { usePermission } from '../permissions';

type Props = {
  resource: string;
  action?: string;
  redirectTo?: any;
  children: React.ReactNode;
};

export function PermissionRouteGuard({
  resource,
  action,
  redirectTo = '/new/(tabs)',
  children,
}: Props) {
  const hydrated = useAppSessionStore((state) => state.hydrated);
  const appSession = useAppSessionStore((state) => state.appSession);
  const { canAccess, canDo } = usePermission();

  if (!hydrated || !appSession) {
    return <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}><ActivityIndicator /></View>;
  }

  const allowed = action ? canDo(resource, action) : canAccess(resource);
  if (!allowed) return <Redirect href={redirectTo} />;

  return <>{children}</>;
}
