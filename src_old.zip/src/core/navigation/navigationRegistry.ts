export type AppNavigationItem = {
  routeName: string;
  title: string;
  resource: string;
  icon: string;
  action?: string;
};

/**
 * Developer registry for top-level Expo navigation.
 * Add one record here when a new top-level module is added.
 * The route file/folder must still exist under app/new/(tabs).
 */
export const APP_NAVIGATION: Record<string, AppNavigationItem> = {
  home: { routeName: 'index', title: 'Home', resource: 'dashboard', icon: 'home' },
  designs: { routeName: 'designs', title: 'Designs', resource: 'designs', icon: 'design-services' },
  costing: { routeName: 'costing', title: 'Costing', resource: 'costing', icon: 'attach-money' },
  orders: { routeName: 'orders', title: 'Orders', resource: 'orders', icon: 'shopping-cart' },
  reports: { routeName: 'reports', title: 'Reports', resource: 'management.reports', icon: 'assessment' },
  permissions: {
    routeName: 'permissions/index',
    title: 'Permissions',
    resource: 'administration.permission_manager',
    action: 'manage',
    icon: 'admin-panel-settings',
  },
};
