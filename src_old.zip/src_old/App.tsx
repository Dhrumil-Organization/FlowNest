import { NavigationContainer } from '@react-navigation/native';
import React, { useEffect } from 'react';
import { ActivityIndicator, StatusBar, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppCoreProvider } from './core/AppCoreProvider';
import { RootNavigator } from './navigation/RootNavigator';
import './registry';
import { useAppSessionStore } from './stores/AppSessionStore';
import { useAppStore } from './stores/AppStore';
import { T } from './theme';

export default function App() {
  const loadLegacyStorage = useAppStore((state) => state.loadFromStorage);
  const hydrateSession = useAppSessionStore((state) => state.hydrate);
  const hydrated = useAppSessionStore((state) => state.hydrated);

  useEffect(() => {
    void Promise.all([loadLegacyStorage(), hydrateSession()]);
  }, [hydrateSession, loadLegacyStorage]);

  if (!hydrated) {
    return (
      <SafeAreaProvider>
        <StatusBar barStyle="light-content" backgroundColor={T.nav} />
        <View style={{ flex: 1, backgroundColor: T.nav, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={T.copper} size="large" />
        </View>
      </SafeAreaProvider>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor={T.nav} />
      <AppCoreProvider>
        <NavigationContainer>
          <RootNavigator />
        </NavigationContainer>
      </AppCoreProvider>
    </SafeAreaProvider>
  );
}
