// // ─────────────────────────────────────────────────────────────
// // FILE: src/navigation/RootNavigator.tsx
// // Routes by real app session token, not static role user.
// // ─────────────────────────────────────────────────────────────

// import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import React from 'react';
// import RoleLoginScreen from '../screens/auth/RoleLoginScreen';
// import { useAppSessionStore } from '../stores/AppSessionStore';

// const Stack = createNativeStackNavigator();

// console.log("hydrated", useAppSessionStore.getState().hydrated);
// console.log("token", useAppSessionStore.getState().token);

// export function RootNavigator() {
//   // const token = useAppSessionStore((s) => s.token);

//   // return (
//   //   <Stack.Navigator screenOptions={{ headerShown: false }}>
//   //     {!token ? (
//   //       <Stack.Screen name="RoleLogin" component={RoleLoginScreen} />
//   //     ) : (
//   //       <Stack.Screen name="Main" component={MainTabs} />
//   //     )}
//   //   </Stack.Navigator>
//   // );
//   const Stack = createNativeStackNavigator();

//   return (
//     <Stack.Navigator>
//       {/* <Stack.Screen
//         name="Test"
//         component={() => null}
//       /> */}
//       <Stack.Screen
//         name="RoleLogin"
//         component={RoleLoginScreen}
//       />
//     </Stack.Navigator>
//   );
// }

import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import RoleLoginScreen from '../screens/auth/RoleLoginScreen';
import { useAppSessionStore } from '../stores/AppSessionStore';
import { MainTabs } from './MainTabs';

const Stack = createNativeStackNavigator();

export function RootNavigator() {
  const token = useAppSessionStore((s) => s.token);

  console.log("token =", token);

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!token ? (
        <Stack.Screen
          name="RoleLogin"
          component={RoleLoginScreen}
        />
      ) : (
        <Stack.Screen
          name="Main"
          component={MainTabs}
        />
      )}
    </Stack.Navigator>
  );
}