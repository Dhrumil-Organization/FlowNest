import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CostingScreen }     from '../../screens/costing/CostingScreen';
import { CostHistoryScreen } from '../../screens/costing/CostHistoryScreen';

const Stack = createNativeStackNavigator();

export function CostingStack() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="CostingMain" component={CostingScreen} />
            <Stack.Screen name="CostHistory" component={CostHistoryScreen} />
        </Stack.Navigator>
    );
}
