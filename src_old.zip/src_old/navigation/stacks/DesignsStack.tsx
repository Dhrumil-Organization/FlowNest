import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { DesignsScreen }      from '../../screens/designs/DesignsScreen';
import { DesignDetailScreen } from '../../screens/designs/DesignDetailScreen';

const Stack = createNativeStackNavigator();

export function DesignsStack() {
    return (
        <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="DesignsMain"  component={DesignsScreen} />
            <Stack.Screen name="DesignDetail" component={DesignDetailScreen} />
        </Stack.Navigator>
    );
}
