import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ExpenseScreen } from '../../screens/expense/ExpenseScreen';

const Stack = createNativeStackNavigator();

export function ExpenseStack() {
    return (
        <Stack.Navigator>
            <Stack.Screen name="ExpenseMain" component={ExpenseScreen} options={{ headerShown: false }} />
        </Stack.Navigator>
    );
}
