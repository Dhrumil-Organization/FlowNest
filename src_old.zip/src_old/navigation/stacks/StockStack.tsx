import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StockScreen } from '../../screens/stock/StockScreen';

const Stack = createNativeStackNavigator();

export function StockStack() {
    return (
        <Stack.Navigator>
            <Stack.Screen name="StockMain" component={StockScreen} options={{ headerShown: false }} />
        </Stack.Navigator>
    );
}
